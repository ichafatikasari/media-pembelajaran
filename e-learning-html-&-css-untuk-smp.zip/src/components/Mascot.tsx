import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';

interface MascotProps {
  message?: string;
  emotion?: 'happy' | 'neutral' | 'surprised' | 'excited' | 'confused';
}

const KATA_KUNCI_TIPS = [
  "Jangan lupa tutup tag HTML kamu ya! 🐱",
  "CSS itu seperti baju mewah untuk kerangka HTML-mu! 🎨",
  "Titik koma (;) di akhir properti CSS jangan sampai ketinggalan ya! 💡",
  "Warna pahlawan kita saat ini adalah hijau toska #10998d! Elegan kan? 😍",
  "HTML untuk struktur halaman, CSS untuk gaya estetika! Kombinasi maut! 🚀",
  "Gunakan selector class (.) untuk kelas khusus, atau tag element secara langsung! 📑",
  "Kemudahan belajar coding dimulai dari sering mencoba sendiri dan membetulkan error! ✨"
];

const Mascot: React.FC<MascotProps> = ({ message: parentMessage, emotion = 'neutral' }) => {
  const [localMessage, setLocalMessage] = useState<string | null>(null);
  const [currentTipIndex, setCurrentTipIndex] = useState(0);
  const [showBubble, setShowBubble] = useState(true);
  const [isMinimized, setIsMinimized] = useState(false);

  const displayMessage = parentMessage || localMessage;

  // Reactivate message bubble whenever a new message is pushed from parent
  useEffect(() => {
    if (parentMessage) {
      setShowBubble(true);
    }
  }, [parentMessage]);

  const handleMascotClick = () => {
    // Cycle tips dynamically when clicked!
    const nextIndex = (currentTipIndex + 1) % KATA_KUNCI_TIPS.length;
    setCurrentTipIndex(nextIndex);
    setLocalMessage(KATA_KUNCI_TIPS[currentTipIndex]);
    setShowBubble(true);
    
    // Auto clear after 6 seconds if parent is not forcing a message
    if (!parentMessage) {
      setTimeout(() => {
        setLocalMessage((prev) => {
          if (prev === KATA_KUNCI_TIPS[currentTipIndex]) {
            return null;
          }
          return prev;
        });
      }, 6000);
    }
  };

  if (isMinimized) {
    return (
      <div className="fixed bottom-4 right-4 md:bottom-6 md:right-6 z-50 pointer-events-auto">
        <motion.button
          onClick={() => {
            setIsMinimized(false);
            setShowBubble(true);
          }}
          whileHover={{ scale: 1.05 }}
          whileTap={{ scale: 0.95 }}
          className="bg-brand hover:bg-brand-dark text-white px-3 py-1.5 rounded-full flex items-center gap-1.5 shadow-lg border border-accent-yellow text-[10px] sm:text-xs font-black tracking-wider uppercase transition-all"
        >
          <span>🐱 Tips Scratch</span>
        </motion.button>
      </div>
    );
  }

  return (
    <div className="fixed bottom-4 right-4 md:bottom-6 md:right-6 z-50 flex flex-col items-end pointer-events-none">
      {/* Speech Bubble */}
      <AnimatePresence>
        {showBubble && displayMessage && (
          <motion.div
            initial={{ opacity: 0, y: 15, scale: 0.85 }}
            animate={{ opacity: 1, y: 0, scale: 1 }}
            exit={{ opacity: 0, scale: 0.85, y: 10 }}
            className="mb-2 bg-white p-3 sm:p-4 rounded-2xl sm:rounded-[2rem] shadow-2xl border-2 border-brand/10 max-w-[180px] sm:max-w-[240px] relative pointer-events-auto cursor-pointer group"
            title="Sembunyikan pesan ini"
            onClick={() => setShowBubble(false)}
          >
            {/* Close speech bubble icon */}
            <button
              onClick={(e) => {
                e.stopPropagation();
                setShowBubble(false);
              }}
              className="absolute top-1.5 right-2 w-4 h-4 rounded-full bg-slate-100 hover:bg-slate-200 flex items-center justify-center text-slate-400 hover:text-slate-600 transition-colors pointer-events-auto"
            >
              <span className="text-[10px] leading-none select-none font-bold">×</span>
            </button>

            <p className="text-[9px] sm:text-xs font-black text-brand uppercase tracking-wider mb-0.5 sm:mb-1 flex items-center gap-1">
              <span>🐱 Scratch Cat</span>
              <span className="text-[8px] sm:text-[9px] bg-accent-yellow text-slate-900 px-1.5 py-0.5 rounded-full font-bold">TIPS</span>
            </p>
            <p className="text-[10px] sm:text-xs font-semibold text-slate-700 leading-relaxed font-sans pr-2">
              {displayMessage}
            </p>
            {/* Speech bubble arrow indicator */}
            <div className="absolute bottom-[-8px] right-5 sm:right-7 w-3.5 h-3.5 bg-white border-r-2 border-b-2 border-brand/10 rotate-45" />
          </motion.div>
        )}
      </AnimatePresence>

      <div className="relative group/mascot pointer-events-auto flex items-center gap-1">
        {/* Minimize Button */}
        <motion.button
          onClick={() => setIsMinimized(true)}
          className="absolute -top-1 -right-1 z-15 w-5 h-5 rounded-full bg-slate-800 hover:bg-slate-950 text-white flex items-center justify-center transition-all opacity-100 md:opacity-0 md:group-hover/mascot:opacity-100 focus:opacity-100 text-xs font-black shadow-lg border border-white"
          title="Sembunyikan maskot"
        >
          −
        </motion.button>

        {/* Styled Mascot Head (Vector Scratch Cat) */}
        <motion.div
          onClick={handleMascotClick}
          whileHover={{ scale: 1.1, rotate: [0, -5, 5, 0] }}
          whileTap={{ scale: 0.9 }}
          animate={{ 
            y: emotion === 'excited' ? [0, -10, 0] : [0, -4, 0],
          }}
          transition={{ 
            y: {
              repeat: Infinity, 
              duration: emotion === 'excited' ? 0.4 : 3,
              ease: "easeInOut"
            }
          }}
          className="w-12 h-12 sm:w-16 sm:h-16 bg-white rounded-2xl sm:rounded-3xl shadow-[0_10px_25px_-5px_rgba(16,153,141,0.3)] flex items-center justify-center border-2 sm:border-4 border-brand pointer-events-auto cursor-pointer relative overflow-hidden group select-none"
          title="Klik aku untuk tips coding!"
        >
          <div className="w-10 h-10 sm:w-14 sm:h-14 relative p-0.5 sm:p-1">
            {/* Custom SVG Scratch Cat */}
            <svg viewBox="0 0 100 100" className="w-full h-full">
            {/* Ears */}
            {/* Left Ear */}
            <path d="M 22,30 L 5,2 Q 22,8 30,22 Z" fill="#f27211" />
            <path d="M 20,27 L 8,7 Q 20,12 26,21 Z" fill="#fae4d7" />
            
            {/* Right Ear */}
            <path d="M 78,30 L 95,2 Q 78,8 70,22 Z" fill="#f27211" />
            <path d="M 76,27 L 92,7 Q 76,12 74,21 Z" fill="#fae4d7" />

            {/* Orange Main Face */}
            <circle cx="50" cy="52" r="34" fill="#f27211" />
            {/* Soft lighter orange inner muzzle */}
            <ellipse cx="50" cy="56" rx="28" ry="24" fill="#fca160" />

            {/* Cheek patches */}
            <circle cx="20" cy="54" r="5" fill="#f27211" />
            <circle cx="80" cy="54" r="5" fill="#f27211" />

            {/* Eyes */}
            <ellipse cx="36" cy="46" rx="10" ry="12" fill="#ffffff" />
            <ellipse cx="64" cy="46" rx="10" ry="12" fill="#ffffff" />

            {/* Pupils & Eyes expression dynamically based on state */}
            {emotion === 'happy' && (
              <>
                {/* Cheerful squinty eyes */}
                <path d="M 28,46 Q 36,54 44,46" stroke="#111827" strokeWidth="3" strokeLinecap="round" fill="none" />
                <path d="M 56,46 Q 64,54 72,46" stroke="#111827" strokeWidth="3" strokeLinecap="round" fill="none" />
              </>
            )}

            {emotion === 'surprised' && (
              <>
                {/* Wide open eyes with tiny black pupil dots */}
                <circle cx="36" cy="46" r="3" fill="#111827" />
                <circle cx="64" cy="46" r="3" fill="#111827" />
              </>
            )}

            {emotion === 'excited' && (
              <>
                {/* Glowing star eyes for excited state */}
                <path d="M 36,40 L 38,44 L 42,45 L 39,48 L 40,52 L 36,50 L 32,52 L 33,48 L 30,45 L 34,44 Z" fill="#facc15" />
                <path d="M 64,40 L 66,44 L 70,45 L 67,48 L 68,52 L 64,50 L 60,52 L 61,48 L 58,45 L 62,44 Z" fill="#facc15" />
              </>
            )}

            {emotion === 'confused' && (
              <>
                {/* Tilted vertical lines for confused look */}
                <line x1="33" y1="42" x2="39" y2="50" stroke="#111827" strokeWidth="3.5" strokeLinecap="round" />
                <line x1="39" y1="42" x2="33" y2="50" stroke="#111827" strokeWidth="3.5" strokeLinecap="round" />
                <line x1="61" y1="42" x2="67" y2="50" stroke="#111827" strokeWidth="3.5" strokeLinecap="round" />
                <line x1="67" y1="42" x2="61" y2="50" stroke="#111827" strokeWidth="3.5" strokeLinecap="round" />
              </>
            )}

            {emotion === 'neutral' && (
              <>
                {/* Standard bright friendly green-tinged pupils with white highlights */}
                <ellipse cx="36" cy="46" rx="5" ry="7" fill="#10998d" />
                <circle cx="36" cy="46" r="3" fill="#111827" />
                <circle cx="34" cy="43" r="1.5" fill="#ffffff" />

                <ellipse cx="64" cy="46" rx="5" ry="7" fill="#10998d" />
                <circle cx="64" cy="46" r="3" fill="#111827" />
                <circle cx="62" cy="43" r="1.5" fill="#ffffff" />
              </>
            )}

            {/* Whiskers */}
            <line x1="16" y1="56" x2="4" y2="54" stroke="#ffffff" strokeWidth="2.5" strokeLinecap="round" />
            <line x1="16" y1="62" x2="2" y2="62" stroke="#ffffff" strokeWidth="2.5" strokeLinecap="round" />
            
            <line x1="84" y1="56" x2="96" y2="54" stroke="#ffffff" strokeWidth="2.5" strokeLinecap="round" />
            <line x1="84" y1="62" x2="98" y2="62" stroke="#ffffff" strokeWidth="2.5" strokeLinecap="round" />

            {/* Snout with small nose */}
            <polygon points="47,60 53,60 50,63" fill="#111827" />
            
            {/* Cute Smile / Mouth */}
            {emotion === 'excited' || emotion === 'happy' ? (
              // Big happy open mouth with a pink tongue
              <>
                <path d="M 42,63 Q 50,71 58,63" stroke="#111827" strokeWidth="3" strokeLinecap="round" fill="none" />
                <path d="M 44,65 Q 50,75 56,65 Z" fill="#ef4444" />
              </>
            ) : (
              // Cute cat wavy mouth
              <path d="M 42,63 C 45,67 49,67 50,64 C 51,67 55,67 58,63" stroke="#111827" strokeWidth="3" fill="none" strokeLinecap="round" />
            )}

            {/* Collar/Scarf using brand color + small yellow tag */}
            <path d="M 28,82 Q 50,90 72,82" stroke="#10998d" strokeWidth="5.5" strokeLinecap="round" fill="none" />
            <circle cx="50" cy="85" r="4.5" fill="#facc15" stroke="#10998d" strokeWidth="1" />
          </svg>
        </div>

        {/* Dynamic decorative shine */}
        <div className="absolute top-0 left-[-100%] w-1/2 h-full bg-white/20 skew-x-[-25deg] group-hover:left-[150%] transition-all duration-[1.2s] ease-out pointer-events-none" />
        </motion.div>
      </div>
    </div>
  );
};

export default Mascot;
