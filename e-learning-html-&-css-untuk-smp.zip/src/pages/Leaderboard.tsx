import React, { useState } from 'react';
import { useStore } from '../store/useStore';
import { Trophy, Gamepad2, Target, Award, Star, Crown, Medal } from 'lucide-react';
import { cn } from '../lib/utils';
import { motion } from 'motion/react';

const Leaderboard: React.FC = () => {
  const [activeTab, setActiveTab] = useState<'game' | 'misi'>('game');
  const user = useStore((state) => state.user);
  const getLeaderboard = useStore((state) => state.getLeaderboard);
  
  const leaderboardData = getLeaderboard();

  // Filter and sort for the current tab
  const sortedData = [...leaderboardData].sort((a, b) => 
    activeTab === 'game' ? b.gameScore - a.gameScore : b.missionScore - a.missionScore
  );

  const top3 = sortedData.slice(0, 3);
  const rest = sortedData.slice(3);

  return (
    <div className="space-y-6 sm:space-y-8 animate-in fade-in duration-700">
      <div className="flex flex-col md:flex-row justify-between items-start md:items-end gap-4 sm:gap-6">
        <div>
          <h1 className="text-2xl sm:text-4xl font-black text-gray-800 flex items-center gap-2 sm:gap-3 uppercase italic">
            <Trophy className="w-8 h-8 sm:w-10 sm:h-10 text-yellow-500" /> Papan Peringkat
          </h1>
          <p className="text-xs sm:text-sm text-gray-500 font-medium italic">"Siapa penguasa kode di kelas ini?"</p>
        </div>

        <div className="flex bg-white p-1 rounded-xl sm:rounded-2xl border border-gray-100 shadow-sm w-full md:w-auto self-center md:self-end">
           <button 
             onClick={() => setActiveTab('game')}
             className={cn(
               "flex-1 md:flex-initial flex items-center justify-center gap-1.5 sm:gap-2 px-3 sm:px-6 py-2 sm:py-2.5 rounded-lg sm:rounded-xl font-black text-[10px] sm:text-xs uppercase tracking-wider sm:tracking-widest transition-all",
               activeTab === 'game' ? "bg-brand text-white border border-accent-yellow shadow-lg shadow-brand-light" : "text-gray-500 hover:bg-gray-50"
             )}
           >
              <Gamepad2 className="w-3.5 h-3.5 sm:w-4 sm:h-4" /> Skor Game
           </button>
           <button 
             onClick={() => setActiveTab('misi')}
             className={cn(
               "flex-1 md:flex-initial flex items-center justify-center gap-1.5 sm:gap-2 px-3 sm:px-6 py-2 sm:py-2.5 rounded-lg sm:rounded-xl font-black text-[10px] sm:text-xs uppercase tracking-wider sm:tracking-widest transition-all",
               activeTab === 'misi' ? "bg-brand text-white border border-accent-yellow shadow-lg shadow-brand-light" : "text-gray-500 hover:bg-gray-50"
             )}
           >
              <Target className="w-3.5 h-3.5 sm:w-4 sm:h-4" /> Skor Misi
           </button>
        </div>
      </div>

      {sortedData.length > 0 ? (
        <>
          {/* Top 3 Visual Podium */}
          <div className="flex items-end justify-center w-full max-w-lg mx-auto gap-1 xs:gap-3 sm:gap-4 py-8 mt-4 overflow-hidden px-1">
            {/* Rank 2 */}
            {top3[1] && (
              <div className="w-[30%] xs:w-28 sm:w-32 flex flex-col items-center">
                <div className="mb-2 text-center w-full">
                   <p className="text-[8px] xs:text-[10px] font-black text-gray-400 uppercase tracking-wider xs:tracking-widest">Peringkat 2</p>
                   <p className="font-bold text-[10px] xs:text-xs sm:text-base text-gray-800 truncate max-w-full px-1">{top3[1].name}</p>
                </div>
                <motion.div 
                  initial={{ scaleY: 0 }}
                  animate={{ scaleY: 1 }}
                  style={{ originY: 1 }}
                  className="w-full h-16 xs:h-24 sm:h-28 bg-gray-200 rounded-t-2xl sm:rounded-t-3xl flex items-center justify-center text-xl xs:text-2xl sm:text-4xl shadow-inner relative"
                >
                   🥈
                   <div className="absolute -bottom-4 text-[9px] xs:text-xs font-black text-gray-400 font-mono">
                      {activeTab === 'game' ? top3[1].gameScore : top3[1].missionScore}
                   </div>
                </motion.div>
              </div>
            )}
            
            {/* Rank 1 */}
            {top3[0] && (
              <div className="w-[36%] xs:w-36 sm:w-40 flex flex-col items-center">
                <div className="mb-4 text-center w-full">
                   <p className="text-[9px] xs:text-xs font-black text-yellow-600 uppercase tracking-wider xs:tracking-[0.2em] animate-pulse">Juara Kelas</p>
                   <p className="text-xs xs:text-sm sm:text-2xl font-black text-gray-800 italic uppercase truncate max-w-full px-1">{top3[0].name}</p>
                </div>
                <motion.div 
                  initial={{ scaleY: 0 }}
                  animate={{ scaleY: 1 }}
                  style={{ originY: 1 }}
                  className="w-full h-24 xs:h-36 sm:h-40 bg-gradient-to-b from-yellow-400 to-yellow-600 rounded-t-2xl sm:rounded-t-[2.5rem] flex items-center justify-center text-3xl xs:text-5xl sm:text-6xl shadow-xl relative"
                >
                   🥇
                   <motion.div 
                     animate={{ scale: [1, 1.2, 1] }} 
                     transition={{ repeat: Infinity, duration: 2 }}
                     className="absolute -top-3 -right-1 xs:-top-4 xs:-right-2 bg-white rounded-full p-1 xs:p-2 shadow-lg border border-yellow-100"
                   >
                     <Star className="w-3 h-3 xs:w-5 xs:h-5 sm:w-6 sm:h-6 text-yellow-500 fill-current" />
                   </motion.div>
                   <div className="absolute -bottom-6 text-sm xs:text-base sm:text-xl font-black text-yellow-700 font-mono">
                      {activeTab === 'game' ? top3[0].gameScore : top3[0].missionScore}
                   </div>
                </motion.div>
              </div>
            )}

            {/* Rank 3 */}
            {top3[2] && (
              <div className="w-[30%] xs:w-28 sm:w-32 flex flex-col items-center">
                <div className="mb-2 text-center w-full">
                   <p className="text-[8px] xs:text-[10px] font-black text-gray-400 uppercase tracking-wider xs:tracking-widest">Peringkat 3</p>
                   <p className="font-bold text-[10px] xs:text-xs sm:text-base text-gray-800 truncate max-w-full px-1">{top3[2].name}</p>
                </div>
                <motion.div 
                  initial={{ scaleY: 0 }}
                  animate={{ scaleY: 1 }}
                  style={{ originY: 1 }}
                  className="w-full h-12 xs:h-16 sm:h-20 bg-orange-100 rounded-t-2xl sm:rounded-t-3xl flex items-center justify-center text-xl xs:text-2xl sm:text-4xl shadow-inner relative"
                >
                   🥉
                   <div className="absolute -bottom-4 text-[9px] xs:text-xs font-black text-orange-400 font-mono">
                      {activeTab === 'game' ? top3[2].gameScore : top3[2].missionScore}
                   </div>
                </motion.div>
              </div>
            )}
          </div>

          {/* Full List Table */}
          <div className="bg-white rounded-2xl sm:rounded-[2.5rem] border border-gray-100 shadow-sm overflow-hidden mt-6 sm:mt-8">
            <div className="overflow-x-auto">
              <table className="w-full text-left">
                <thead>
                  <tr className="bg-gray-50 text-[8px] sm:text-[10px] font-black text-gray-400 uppercase tracking-widest border-b">
                    <th className="px-3 sm:px-8 py-4 sm:py-5">#</th>
                    <th className="px-3 sm:px-8 py-4 sm:py-5">Nama Siswa</th>
                    <th className="px-3 sm:px-8 py-4 sm:py-5 text-right">
                      {activeTab === 'game' ? 'Poin Game' : 'Poin Misi'}
                    </th>
                    <th className="px-3 sm:px-8 py-4 sm:py-5 text-center">Status</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-gray-50">
                  {sortedData.map((student, index) => {
                    const isUser = user && student.name.toUpperCase() === user.displayName.toUpperCase();
                    return (
                      <motion.tr 
                        key={student.name}
                        initial={{ opacity: 0, y: 10 }}
                        animate={{ opacity: 1, y: 0 }}
                        transition={{ delay: index * 0.05 }}
                        className={cn(
                          "group hover:bg-slate-50 transition-colors",
                          isUser ? "bg-brand-light/50" : ""
                        )}
                      >
                        <td className="px-3 sm:px-8 py-3.5 sm:py-5">
                           <div className={cn(
                             "w-6 h-6 sm:w-7 sm:h-7 rounded-lg flex items-center justify-center font-black text-[9px] sm:text-[10px]",
                             index === 0 ? "bg-yellow-400 text-white" : 
                             index === 1 ? "bg-gray-300 text-white" :
                             index === 2 ? "bg-orange-300 text-white" :
                             "bg-gray-50 text-gray-400"
                           )}>
                              {index + 1}
                           </div>
                        </td>
                        <td className="px-3 sm:px-8 py-3.5 sm:py-5">
                          <div className="flex items-center gap-2 sm:gap-3">
                             <div className={cn(
                               "w-8 h-8 sm:w-9 sm:h-9 rounded-lg sm:rounded-xl flex items-center justify-center font-black text-[10px] sm:text-xs border-b-2",
                               isUser ? "bg-brand text-white border-brand-dark" : "bg-white text-slate-300 border-slate-100 shadow-sm"
                             )}>
                               {student.name.charAt(0)}
                             </div>
                             <div className="flex flex-col min-w-0">
                               <span className={cn(
                                 "font-bold text-xs sm:text-sm tracking-tight truncate max-w-[120px] xs:max-w-[180px] sm:max-w-xs",
                                 isUser ? "text-brand" : "text-gray-700"
                               )}>
                                 {student.name}
                               </span>
                               {isUser && <span className="text-[7px] sm:text-[8px] font-black uppercase text-brand tracking-widest leading-none mt-0.5">Ini Kamu</span>}
                             </div>
                          </div>
                        </td>
                        <td className="px-3 sm:px-8 py-3.5 sm:py-5 text-right font-mono font-black text-xs sm:text-base text-gray-800">
                           {activeTab === 'game' ? student.gameScore : student.missionScore}
                        </td>
                        <td className="px-3 sm:px-8 py-3.5 sm:py-5 text-center">
                           <div className="flex justify-center">
                              {index < 3 ? <Medal className={cn("w-4 h-4 sm:w-5 sm:h-5", index === 0 ? "text-yellow-400" : index === 1 ? "text-slate-300" : "text-orange-300")} /> : <Star className="w-3.5 h-3.5 sm:w-4 sm:h-4 text-gray-100" />}
                           </div>
                        </td>
                      </motion.tr>
                    );
                  })}
                </tbody>
              </table>
            </div>
          </div>
        </>
      ) : (
         <div className="py-16 sm:py-24 flex flex-col items-center justify-center text-center bg-white rounded-2xl sm:rounded-[3rem] border border-gray-100 shadow-sm px-4">
            <div className="w-16 h-16 sm:w-20 sm:h-20 bg-slate-50 rounded-full flex items-center justify-center mb-4 sm:mb-6">
               <Star className="w-8 h-8 sm:w-10 sm:h-10 text-slate-200" />
            </div>
            <h3 className="text-lg sm:text-xl font-black text-gray-800 uppercase italic">Papan Masih Kosong!</h3>
            <p className="text-xs sm:text-sm text-gray-400 mt-2 max-w-sm font-medium leading-relaxed">
              Belum ada siswa yang menyelesaikan permainan. Ayo jadi yang pertama muncul di sini!
            </p>
            <button 
              onClick={() => window.location.href = '/misi'}
              className="mt-6 sm:mt-8 px-6 sm:px-8 py-2.5 sm:py-3 bg-brand hover:bg-brand-dark border border-accent-yellow text-white rounded-xl sm:rounded-2xl font-black uppercase tracking-widest text-[10px] sm:text-xs shadow-xl shadow-brand-light hover:scale-105 active:scale-95 transition-all"
            >
               Mulai Belajar
            </button>
         </div>
      )}

      {user && user.role === 'siswa' && (
        <div className="bg-slate-900 rounded-2xl sm:rounded-3xl p-5 sm:p-8 text-white relative overflow-hidden">
          <div className="relative z-10 flex flex-col md:flex-row items-center justify-between gap-4 sm:gap-6">
             <div className="flex items-center gap-3 sm:gap-4">
                <div className="bg-white/10 p-3 sm:p-4 rounded-xl sm:rounded-2xl backdrop-blur-md shrink-0">
                   <Award className="w-6 h-6 sm:w-8 sm:h-8 text-yellow-400" />
                </div>
                <div>
                  <h4 className="text-base sm:text-xl font-bold italic uppercase tracking-tight">Semangat, {user.displayName}!</h4>
                  <p className="text-white/50 text-[10px] sm:text-xs font-medium">Kalahkan teman-temanmu dengan menyelesaikan lebih banyak tantangan.</p>
                </div>
             </div>
             <div className="text-center md:text-right shrink-0 w-full md:w-auto">
                <p className="text-[8px] sm:text-[10px] font-black uppercase text-white/30 tracking-[0.2em] mb-0.5 sm:mb-1">Skor Kamu</p>
                <p className="text-3xl sm:text-5xl font-black font-mono">
                  {leaderboardData.find(s => s.name.toUpperCase() === user.displayName.toUpperCase())?.[activeTab === 'game' ? 'gameScore' : 'missionScore'] || 0}
                </p>
             </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default Leaderboard;
