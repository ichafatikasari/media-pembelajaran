import React from 'react';
import { Outlet, Link, useLocation } from 'react-router-dom';
import Navbar from './Navbar';
import Mascot from './Mascot';
import { useStore } from '../store/useStore';
import { BookOpen, Play, Gamepad2, Target, FolderSearch, Trophy, Heart, Sparkles, Laptop, Users } from 'lucide-react';

const Layout: React.FC = () => {
  const user = useStore((state) => state.user);
  const location = useLocation();

  const isMisiDetailPage = location.pathname.startsWith('/misi/') && location.pathname !== '/misi';

  const navItems = [
    { name: 'Materi', path: '/materi', icon: BookOpen },
    { name: 'Video', path: '/video', icon: Play },
    { name: 'Game', path: '/game', icon: Gamepad2 },
    { name: 'Misi', path: '/misi', icon: Target },
    { name: 'Portfolio', path: '/portfolio', icon: FolderSearch },
    { name: 'Leaderboard', path: '/leaderboard', icon: Trophy },
  ];

  const filteredNavItems = user?.role === 'guru' 
    ? [
        { name: 'Materi', path: '/materi', icon: BookOpen },
        { name: 'Video', path: '/video', icon: Play },
        { name: 'Panel Guru', path: '/panel-guru', icon: Users }
      ]
    : navItems;

  return (
    <div className="min-h-screen bg-gray-50 flex flex-col">
      <Navbar />
      <main className="flex-1 w-full max-w-7xl mx-auto p-4 sm:p-6 lg:p-8">
        <Outlet />
      </main>
      
      {/* 🌟 Footer Elegan (Tanpa Gradasi, Solid Warna Brand #10998d, Aksen Putih & Kuning) */}
      <footer className="bg-brand text-white border-t-4 border-accent-yellow">
        <div className="max-w-7xl mx-auto px-6 py-12">
          
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8 pb-8 border-b border-brand-dark">
            
            {/* Bagian Info Platform */}
            <div className="space-y-4">
              <div className="flex items-center gap-2">
                <div className="bg-white p-1.5 rounded-lg text-xl shadow-md">
                  🚀
                </div>
                <span className="text-xl font-black text-white tracking-tight">
                  E-Learn <span className="text-accent-yellow">Web</span>
                </span>
              </div>
              <p className="text-brand-light text-sm font-medium leading-relaxed">
                Platform pembelajaran interaktif untuk siswa SMP/MTs dalam menguasai HTML dan CSS. Belajar menyenangkan melalui permainan, materi interaktif dan tantangan coding langsung!
              </p>
            </div>

            {/* Bagian Link Navigasi Pintas */}
            <div className="space-y-4">
              <h3 className="text-accent-yellow font-extrabold text-sm uppercase tracking-wider flex items-center gap-2">
                <Laptop size={16} /> Pintasan Belajar
              </h3>
              <ul className="grid grid-cols-2 gap-2 text-sm">
                {filteredNavItems.map((item) => (
                  <li key={item.name}>
                    <Link 
                      to={item.path} 
                      className="flex items-center gap-2 text-brand-light hover:text-white hover:translate-x-1 transition-all font-semibold"
                    >
                      <item.icon className="w-4 h-4 text-accent-yellow shrink-0" />
                      {item.name}
                    </Link>
                  </li>
                ))}
              </ul>
            </div>

            {/* Bagian Motivasi Coding */}
            <div className="bg-brand-dark p-6 rounded-2xl border border-accent-yellow/20 flex flex-col justify-between">
              <div>
                <div className="flex items-center gap-1.5 text-accent-yellow mb-2">
                  <Sparkles size={16} />
                  <span className="text-[10px] font-black uppercase tracking-widest">Inspirasi Hari Ini</span>
                </div>
                <p className="text-white text-xs font-semibold leading-relaxed italic">
                  "Satu-satunya cara untuk belajar menulis kode baru adalah dengan terus mencoba secara mandiri dan tidak takut dengan error!"
                </p>
              </div>
              <p className="text-[10px] text-brand-light font-black uppercase mt-4">
                Yuk Semangat Belajar! ✨
              </p>
            </div>

          </div>

          {/* Bagian Hak Cipta & Kreasi */}
          <div className="pt-8 flex flex-col md:flex-row items-center justify-between gap-4 text-xs font-medium text-brand-light">
            <p>
              &copy; {new Date().getFullYear()} <span className="text-white font-bold">E-Learn Web SMP/MTs</span>. Hak Cipta Dilindungi.
            </p>
            <p className="flex items-center gap-1">
              Dibuat dengan <Heart className="w-4 h-4 text-accent-yellow fill-accent-yellow animate-pulse shrink-0" /> untuk Siswa SMP/MTs Cerdas
            </p>
          </div>
          
        </div>
      </footer>
      {!isMisiDetailPage && <Mascot />}
    </div>
  );
};

export default Layout;
