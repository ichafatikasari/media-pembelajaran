// Guru bisa mengatur password kelas di sini
export const CLASS_PASSWORD = "belajar123";
