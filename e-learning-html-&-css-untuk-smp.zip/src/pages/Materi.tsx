import React, { useState } from 'react';
import { topics } from '../data/materi.ts';
import { useStore } from '../store/useStore';
import { 
  Book, 
  Lightbulb, 
  CheckCircle, 
  ChevronRight, 
  Info, 
  Sparkles, 
  Star, 
  Zap,
  Code2
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { cn } from '../lib/utils';
import confetti from 'canvas-confetti';
import { useNavigate } from 'react-router-dom';

const Materi: React.FC = () => {
  const [activeTopicId, setActiveTopicId] = useState(topics[0].id);
  const completedMateri = useStore((state) => state.materiCompleted);
  const completeMateri = useStore((state) => state.completeMateri);
  const navigate = useNavigate();

  const activeTopic = topics.find(t => t.id === activeTopicId) || topics[0];

  const renderDescription = (text: string) => {
    const parts = text.split('**');
    return parts.map((part, i) => {
      if (i % 2 === 1) {
        return <strong key={i} className="font-black text-slate-900 border-b-2 border-brand/10 bg-brand-light/20 px-1 py-0.5 rounded-md">{part}</strong>;
      }
      return part;
    });
  };

  const handleComplete = (id: string) => {
    if (!completedMateri.includes(id)) {
      completeMateri(id);
      confetti({
        particleCount: 150,
        spread: 100,
        origin: { y: 0.6 },
        colors: ['#2563eb', '#8b5cf6', '#10b981', '#f59e0b']
      });
    }
  };

  return (
    <div className="flex flex-col lg:flex-row gap-8">
      {/* Sidebar Navigation - Tetap Dipertahankan */}
      <aside className="lg:w-64 flex-shrink-0">
        <div className="bg-white rounded-2xl border border-gray-100 shadow-sm overflow-hidden sticky top-24">
          <div className="p-4 bg-gray-50 border-b border-gray-100">
            <h3 className="font-bold text-gray-800 flex items-center gap-2">
              <Book className="w-4 h-4" /> Daftar Materi
            </h3>
          </div>
          <div className="p-2 space-y-1">
            {topics.map((topic) => (
              <button
                key={topic.id}
                onClick={() => setActiveTopicId(topic.id)}
                className={cn(
                  "w-full flex items-center justify-between p-3 rounded-xl text-left text-sm font-medium transition-all group",
                  activeTopicId === topic.id 
                    ? "bg-brand text-white border border-accent-yellow shadow-lg shadow-brand-light" 
                    : "text-gray-500 hover:bg-brand-light hover:text-brand-dark"
                )}
              >
                <span className="truncate">{topic.title}</span>
                {completedMateri.includes(topic.id) && (
                  <CheckCircle className={cn(
                    "w-4 h-4 shrink-0",
                    activeTopicId === topic.id ? "text-white" : "text-green-500"
                  )} />
                )}
              </button>
            ))}
          </div>
        </div>
      </aside>

      {/* Main Content - Perubahan Isi sesuai Permintaan */}
      <div className="flex-1">
        <AnimatePresence mode="wait">
          <motion.div
            key={activeTopicId}
            initial={{ opacity: 0, scale: 0.95 }}
            animate={{ opacity: 1, scale: 1 }}
            exit={{ opacity: 0, x: -20 }}
            className="space-y-6"
          >
            <div className="bg-white rounded-[40px] border border-gray-100 shadow-sm overflow-hidden">
               {/* Header Bagian Isi */}
               <div className="bg-slate-900 p-8 sm:p-12 text-white relative">
                  <div className="relative z-10">
                    <span className="inline-block px-4 py-1.5 bg-brand-light/20 text-accent-yellow rounded-full text-[10px] font-black uppercase tracking-widest mb-4 border border-brand/30">
                      Materi Aktif
                    </span>
                    <h1 className="text-4xl sm:text-5xl font-black mb-4 uppercase italic leading-tight">
                      {activeTopic.title}
                    </h1>
                    <p className="text-white/60 font-medium italic">"{activeTopic.shortDesc}"</p>
                  </div>
                  <div className="absolute top-0 right-0 w-1/3 h-full bg-gradient-to-l from-brand/10 to-transparent pointer-events-none" />
               </div>

               <div className="p-8 sm:p-12 grid grid-cols-1 xl:grid-cols-2 gap-12">
                  {/* Kolom Kiri: Penjelasan & Analogi */}
                  <div className="space-y-10">
                    <div>
                      <h4 className="text-[10px] font-black text-brand uppercase tracking-[0.3em] mb-4 flex items-center gap-2">
                         <Sparkles size={14} className="fill-current" /> Penjelasan Materi
                      </h4>
                      <div className="text-lg text-slate-600 leading-relaxed font-medium whitespace-pre-line">
                         {renderDescription(activeTopic.description)}
                      </div>
                    </div>

                    <div className="bg-amber-50 p-8 rounded-[32px] border border-amber-100 relative overflow-hidden group shadow-sm">
                       <div className="absolute top-0 right-0 w-16 h-16 bg-white/50 blur-2xl rounded-full -mr-8 -mt-8" />
                       <h4 className="text-[10px] font-black uppercase tracking-widest mb-4 text-amber-600 opacity-70 flex items-center gap-2">
                          <Lightbulb size={14} /> Analogi Guru Miau
                       </h4>
                       <p className="text-xl font-serif italic leading-relaxed text-amber-900">
                          "{activeTopic.analogy}"
                       </p>
                    </div>
                  </div>

                  {/* Kolom Kanan: Highlight, Code, & Action */}
                  <div className="space-y-10">
                    <div className="bg-slate-50 p-8 rounded-[32px] border border-slate-100">
                      <h4 className="text-[10px] font-black text-slate-400 uppercase tracking-[0.3em] mb-4 flex items-center gap-2">
                         <Star size={14} className="text-amber-500 fill-current" /> Poin Penting
                      </h4>
                      <p className="text-xl font-bold text-slate-900 leading-tight">
                         {activeTopic.highlight}
                      </p>
                    </div>

                    <div className="bg-slate-950 rounded-[32px] overflow-hidden shadow-xl border border-white/5">
                       <div className="bg-white/5 px-6 py-4 border-b border-white/5 flex items-center justify-between">
                          <div className="flex items-center gap-2">
                             <div className="w-2 h-2 rounded-full bg-red-400" />
                             <div className="w-2 h-2 rounded-full bg-yellow-400" />
                             <div className="w-2 h-2 rounded-full bg-emerald-400" />
                          </div>
                          <span className="text-[10px] font-bold text-white/30 uppercase tracking-widest">Contoh Kode</span>
                       </div>
                       <pre className="p-8 text-brand-light font-mono text-sm overflow-x-auto">
                          <code>{activeTopic.example}</code>
                       </pre>
                    </div>

                    <div className="flex flex-col sm:flex-row gap-4 pt-4">
                       <button 
                         onClick={() => handleComplete(activeTopic.id)}
                         disabled={completedMateri.includes(activeTopic.id)}
                         className={cn(
                           "flex-1 py-5 rounded-2xl font-black text-sm uppercase tracking-widest shadow-xl transition-all flex items-center justify-center gap-2",
                           completedMateri.includes(activeTopic.id)
                            ? "bg-green-100 text-green-600 cursor-default"
                            : "bg-brand hover:bg-brand-dark border border-accent-yellow text-white shadow-brand-light hover:scale-[1.02] active:scale-95"
                         )}
                       >
                         {completedMateri.includes(activeTopic.id) ? (
                           <><CheckCircle size={18} /> Sudah Paham ✅</>
                         ) : (
                           <>Saya Sudah Paham! <Zap size={18} className="fill-current" /></>
                         )}
                       </button>
                       <button 
                         onClick={() => navigate('/game')}
                         className="flex-1 py-5 bg-slate-900 text-white rounded-2xl font-black text-sm uppercase tracking-widest hover:bg-black transition-all flex items-center justify-center gap-2"
                       >
                         Coba Praktek <Code2 size={18} />
                       </button>
                    </div>

                    <div className="flex items-center justify-center gap-2 text-gray-400 text-xs italic">
                      <Info size={14} />
                      <span>Selesaikan materi untuk mendapatkan poin tambahan!</span>
                    </div>
                  </div>
               </div>
            </div>
          </motion.div>
        </AnimatePresence>
      </div>
    </div>
  );
};

export default Materi;

