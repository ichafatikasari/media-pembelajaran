import React, { useState, useEffect, useRef } from 'react';
import { useParams, useNavigate, Navigate } from 'react-router-dom';
import { useStore } from '../store/useStore';
import { missions } from '../data/missions';
import { 
  ArrowLeft, 
  Play, 
  RotateCcw, 
  Save, 
  Sparkles, 
  Target, 
  CheckCircle, 
  Smartphone, 
  Code2, 
  Eye,
  Trophy,
  Home
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import confetti from 'canvas-confetti';
import { cn } from '../lib/utils';
import Mascot from '../components/Mascot';

const MisiDetail: React.FC = () => {
  const { id } = useParams<{ id: string }>();
  const navigate = useNavigate();
  
  const user = useStore((state) => state.user);
  const missionsProgress = useStore((state) => state.missionsProgress);
  const completeMission = useStore((state) => state.completeMission);
  
  const misi = missions.find(m => m.id === id);
  const isPreviouslyCompleted = missionsProgress[misi?.id || '']?.completed;

  const [html, setHtml] = useState(misi?.initialHtml || '');
  const [css, setCss] = useState(misi?.initialCss || '');
  const [activeTab, setActiveTab] = useState<'html' | 'css'>('html');
  const [feedback, setFeedback] = useState<{ type: 'success' | 'partial' | 'error' | null, message: string }>({ type: null, message: '' });
  const [mascotMessage, setMascotMessage] = useState<string>('Halo! Aku siap bantuin kamu coding!');
  const [mascotEmotion, setMascotEmotion] = useState<'happy' | 'neutral' | 'surprised' | 'excited' | 'confused'>('neutral');
  const [showResult, setShowResult] = useState(false);
  const [earnedPoints, setEarnedPoints] = useState(0);

  useEffect(() => {
    if (misi) {
      setHtml(misi.initialHtml);
      setCss(misi.initialCss);
      setFeedback({ type: null, message: '' });
      setEarnedPoints(0);
      setMascotMessage(`Tantangan baru: ${misi.title}. Ayo semangat!`);
      setMascotEmotion('neutral');
    }
  }, [misi?.id]);

  if (!misi) return <Navigate to="/misi" replace />;

  const checklist = misi.checks.map(check => ({
    ...check,
    done: check.isCss 
      ? new RegExp(check.regex, 'i').test(css) 
      : new RegExp(check.regex, 'i').test(html)
  }));

  const srcDoc = `
    <!DOCTYPE html>
    <html>
      <head>
        <meta charset="UTF-8">
        <style>
          @import url('https://fonts.googleapis.com/css2?family=Inter:wght@400;700;900&display=swap');
          * { box-sizing: border-box; }
          body { 
            font-family: 'Inter', sans-serif; 
            display: flex; 
            flex-direction: column; 
            align-items: center; 
            justify-content: center; 
            min-height: 100vh; 
            margin: 0; 
            padding: 20px;
            background-color: white;
            color: #1e293b;
            text-align: center;
          }
          button {
            cursor: pointer;
            font-family: inherit;
            background-color: #f1f5f9;
            border: 2px solid #cbd5e1;
            border-radius: 8px;
            font-weight: bold;
            outline: none;
            transition: all 0.2s;
            -webkit-appearance: none;
            appearance: none;
          }
          /* User Custom CSS */
          ${css}
        </style>
      </head>
      <body>
        ${html}
      </body>
    </html>
  `;

  const handleCheckCode = () => {
    const totalChecks = checklist.length;
    const passedChecks = checklist.filter(item => item.done).length;
    
    if (passedChecks === totalChecks) {
      setEarnedPoints(misi.points);
      setFeedback({ 
        type: 'success', 
        message: `PERFECT! Luar biasa, tantangan ini selesai dengan sempurna! 🎯 (+${misi.points} Poin)` 
      });
      setMascotMessage("WAW! Kamu luar biasa! Klik Simpan Proyek untuk lanjut!");
      setMascotEmotion('excited');
      confetti({
         particleCount: 150,
         spread: 70,
         origin: { y: 0.6 },
         colors: ['#2563eb', '#f59e0b', '#10b981']
      });
    } else if (passedChecks > 0) {
      const partialPoints = Math.floor(misi.points / 2);
      setEarnedPoints(partialPoints);
      setFeedback({ 
        type: 'partial', 
        message: `Hampir benar! Kamu menyelesaikan ${passedChecks}/${totalChecks} bagian. Kamu dapat poin setengah! (+${partialPoints} Poin)` 
      });
      setMascotMessage("Bagus! Tapi masih ada yang kurang. Cek lagi ya atau simpan saja!");
      setMascotEmotion('happy');
    } else {
      setFeedback({ 
        type: 'error', 
        message: `Waduh, belum ada yang benar nih. Yuk coba pelajari lagi intruksinya!` 
      });
      setMascotMessage("Jangan menyerah! Coba baca lagi petunjuk di samping.");
      setMascotEmotion('confused');
    }
  };

  const handleReset = () => {
    if (window.confirm('Kamu yakin ingin mengulang dari awal? Semua kodemu akan hilang.')) {
      setHtml(misi.initialHtml);
      setCss(misi.initialCss);
      setFeedback({ type: null, message: '' });
      setEarnedPoints(0);
      setMascotMessage("Oke, kita ulang lagi dari awal. Jangan khawatir, kamu pasti bisa! 💪");
      setMascotEmotion('surprised');
    }
  };

  const handleSave = () => {
    // If not checked yet, point is 0 or check it now
    let finalPoints = earnedPoints;
    if (finalPoints === 0 && checklist.some(c => c.done)) {
       finalPoints = Math.floor(misi.points / 2);
    }
    
    completeMission(misi.id, finalPoints, html + '\n<style>\n' + css + '\n</style>');
    setShowResult(true);
  };

  return (
    <div className="min-h-screen bg-slate-50 flex flex-col pt-3 px-3 sm:pt-4 sm:px-4 pb-16 overflow-x-hidden">
      <Mascot message={mascotMessage} emotion={mascotEmotion} />
      
      {/* Header */}
      <header className="flex flex-col md:flex-row md:items-center justify-between gap-4 sm:gap-6 p-4 sm:p-6 rounded-2xl sm:rounded-[32px] bg-white border border-gray-100 shadow-xl mb-4 sm:mb-6">
        <div className="flex items-center gap-3 sm:gap-4">
           <button 
             onClick={() => navigate('/misi')}
             className="p-2 sm:p-3 hover:bg-slate-50 rounded-xl sm:rounded-2xl transition-all border border-transparent hover:border-slate-100"
           >
             <ArrowLeft className="w-5 h-5 sm:w-6 sm:h-6 text-slate-600" />
           </button>
           <div>
              <div className="flex items-center gap-1.5 text-brand mb-0.5 sm:mb-1">
                 <Code2 size={12} className="animate-pulse" />
                 <span className="text-[9px] sm:text-[10px] font-black uppercase tracking-[0.2em]">{misi.category} Mission</span>
              </div>
              <h2 className="text-xl sm:text-2xl font-black text-slate-900 tracking-tight italic uppercase">{misi.title}</h2>
           </div>
        </div>
        <div className="flex flex-wrap md:flex-nowrap gap-2 sm:gap-3 w-full md:w-auto">
          <button 
            onClick={handleReset} 
            className="flex-1 sm:flex-initial justify-center px-4 sm:px-6 py-2.5 sm:py-3 border border-slate-200 bg-white text-slate-400 hover:text-slate-600 hover:border-slate-300 rounded-xl sm:rounded-2xl font-black text-[9px] sm:text-[10px] uppercase tracking-widest transition-all active:scale-95 flex items-center gap-1.5"
          >
            <RotateCcw size={12} /> Reset
          </button>
          
          <button 
            onClick={handleCheckCode}
            className="flex-1 sm:flex-initial justify-center px-4 sm:px-8 py-2.5 sm:py-3 bg-emerald-600 text-white rounded-xl sm:rounded-2xl font-black text-[9px] sm:text-[10px] uppercase tracking-[0.15em] sm:tracking-[0.2em] shadow-xl shadow-emerald-100 hover:scale-105 active:scale-95 flex items-center gap-1.5 transition-all"
          >
            <Play size={14} fill="white" /> Cek Hasil
          </button>

          <button 
            disabled={earnedPoints === 0 && !isPreviouslyCompleted}
            onClick={handleSave} 
            className="flex-1 sm:flex-initial justify-center px-4 sm:px-8 py-2.5 sm:py-3 bg-brand hover:bg-brand-dark text-white rounded-xl sm:rounded-2xl font-black text-[9px] sm:text-[10px] uppercase tracking-[0.15em] sm:tracking-[0.2em] shadow-xl shadow-brand-light hover:scale-105 active:scale-95 disabled:grayscale disabled:opacity-50 flex items-center gap-1.5 transition-all border border-accent-yellow"
          >
            <Save size={14} /> Simpan
          </button>
        </div>
      </header>


      <div className="flex-1 grid grid-cols-1 lg:grid-cols-12 gap-6 pb-12">
        {/* LEFT: Instructions & Feedback */}
        <div className="lg:col-span-3 flex flex-col gap-6">
           {/* Objective & Sample */}
           <div className="bg-white p-6 rounded-3xl border border-gray-100 shadow-sm flex flex-col gap-4">
              <h4 className="font-black text-slate-900 flex items-center gap-2 text-[10px] uppercase tracking-widest">
                 <Target size={16} className="text-brand" /> Objective
              </h4>
              <p className="text-sm text-slate-600 font-medium leading-relaxed italic">
                 "{misi.mission}"
              </p>
           </div>
           
           {/* Requirements */}
           <div className="bg-white p-6 rounded-3xl border border-gray-100 shadow-sm">
              <h4 className="font-black text-slate-400 mb-4 text-[10px] uppercase tracking-widest">Syarat Selesai:</h4>
              <ul className="space-y-4">
                 {checklist.map(item => (
                   <li key={item.id} className="flex items-start gap-3">
                      <div className={cn(
                        "mt-0.5 w-5 h-5 rounded-lg flex items-center justify-center transition-all border",
                        item.done ? "bg-emerald-500 border-emerald-600 text-white shadow-lg shadow-emerald-100" : "bg-slate-50 border-slate-200 text-transparent"
                      )}>
                         <CheckCircle size={12} fill="currentColor" />
                      </div>
                      <span className={cn(
                        "text-xs font-bold leading-tight transition-all",
                        item.done ? 'text-slate-300 line-through' : 'text-slate-700'
                      )}>{item.text}</span>
                   </li>
                 ))}
              </ul>
           </div>

           <AnimatePresence>
            {feedback.type && (
              <motion.div
                initial={{ y: 20, opacity: 0 }}
                animate={{ y: 0, opacity: 1 }}
                exit={{ y: 20, opacity: 0 }}
                className="p-6 bg-emerald-600 rounded-2xl flex flex-col gap-3 shadow-xl shadow-emerald-100 text-white"
              >
                <div className="w-10 h-10 bg-white/20 rounded-xl flex items-center justify-center">
                   <Sparkles size={20} fill="white" />
                </div>
                <p className="font-black text-xs uppercase tracking-widest leading-snug">{feedback.message}</p>
              </motion.div>
            )}
          </AnimatePresence>
        </div>

        {/* MIDDLE: Editor */}
        <div className="lg:col-span-4 flex flex-col min-h-[350px] sm:min-h-[400px]">
          <div className="flex-1 bg-white rounded-2xl sm:rounded-[32px] flex flex-col overflow-hidden shadow-2xl border border-gray-100">
            <div className="flex px-3 sm:px-4 pt-3 sm:pt-4 gap-1.5 sm:gap-2 bg-slate-50 border-b border-gray-100">
               <button 
                  onClick={() => setActiveTab('html')}
                  className={cn(
                    "px-4 sm:px-6 py-2.5 sm:py-3 text-[9px] sm:text-[10px] font-black uppercase tracking-widest transition-all rounded-t-xl sm:rounded-t-2xl flex items-center gap-1.5 sm:gap-2",
                    activeTab === 'html' ? "bg-white text-brand font-black shadow-sm" : "text-slate-400 hover:text-slate-600"
                  )}
               >
                  <Code2 size={11} /> index.html
               </button>
               <button 
                  onClick={() => setActiveTab('css')}
                  className={cn(
                    "px-4 sm:px-6 py-2.5 sm:py-3 text-[9px] sm:text-[10px] font-black uppercase tracking-widest transition-all rounded-t-xl sm:rounded-t-2xl flex items-center gap-1.5 sm:gap-2",
                    activeTab === 'css' ? "bg-white text-brand font-black shadow-sm" : "text-slate-400 hover:text-slate-600"
                  )}
               >
                  <Sparkles size={11} fill="white" className="text-slate-400" /> styles.css
               </button>
            </div>
            <textarea
              value={activeTab === 'html' ? html : css}
              onChange={(e) => activeTab === 'html' ? setHtml(e.target.value) : setCss(e.target.value)}
              className="flex-1 p-4 sm:p-8 font-mono text-xs sm:text-sm resize-none focus:outline-none bg-transparent text-slate-800 font-medium leading-relaxed caret-brand"
              spellCheck={false}
              placeholder={activeTab === 'html' ? "Tulis HTML di sini..." : "Tulis CSS di sini..."}
            />
            <div className="p-3 sm:p-4 bg-slate-50 border-t border-gray-100 text-[9px] sm:text-[10px] font-mono text-slate-400 flex justify-between">
               <span>{activeTab === 'html' ? 'Type: HTML5' : 'Type: CSS3'}</span>
               <span>Lines: {(activeTab === 'html' ? html : css).split('\n').length}</span>
            </div>
          </div>
        </div>

        {/* RIGHT: Preview */}
        <div className="lg:col-span-5 flex flex-col min-h-[450px] sm:min-h-[500px]">
          <div className="flex-1 rounded-2xl sm:rounded-[32px] overflow-hidden bg-slate-200 border border-gray-100 relative flex flex-col shadow-inner">
            <div className="bg-white border-b border-gray-100 px-4 sm:px-6 py-3 sm:py-4 flex items-center justify-between">
              <div className="flex items-center gap-2 sm:gap-3">
                 <div className="w-7 h-7 sm:w-8 sm:h-8 bg-brand-light text-brand rounded-lg flex items-center justify-center shadow-sm">
                    <Smartphone size={14} />
                  </div>
                  <span className="text-[9px] sm:text-[10px] font-black text-slate-800 uppercase tracking-widest">Live View</span>
              </div>
              <div className="flex items-center gap-1.5 sm:gap-2">
                 <div className="w-1.5 h-1.5 sm:w-2 sm:h-2 rounded-full bg-emerald-400 animate-pulse"></div>
                 <span className="text-[9px] sm:text-[10px] font-bold text-slate-400">Sync Aktif</span>
              </div>
            </div>
            
            <div className="flex-1 p-3 sm:p-6 md:p-12 flex items-center justify-center overflow-auto bg-[radial-gradient(#e2e8f0_1px,transparent_1px)] [background-size:20px_20px]">
               <div className="w-[260px] sm:w-[300px] h-[450px] sm:h-[580px] bg-white rounded-[32px] sm:rounded-[48px] border-[8px] sm:border-[12px] border-slate-900 shadow-2xl overflow-hidden relative flex flex-col shrink-0">
                  <div className="absolute top-0 left-1/2 -translate-x-1/2 w-24 sm:w-32 h-4 sm:h-6 bg-slate-900 rounded-b-xl sm:rounded-b-2xl z-20" />
                  <iframe 
                    srcDoc={srcDoc}
                    className="w-full h-full border-none"
                    title="preview"
                    sandbox="allow-scripts"
                  />
                  
                  {/* Floating Action for Student */}
                  <div className="absolute bottom-8 right-3 flex flex-col gap-2.5 items-center z-10">
                     <div className="w-8 h-8 sm:w-10 sm:h-10 p-0.5 bg-brand rounded-full shadow-lg shadow-brand-light border border-accent-yellow">
                          <div className="w-full h-full bg-white rounded-full overflow-hidden p-0.5">
                             <img src={`https://api.dicebear.com/7.x/avataaars/svg?seed=${user?.displayName || 'Student'}`} alt="avatar" />
                          </div>
                     </div>
                  </div>
               </div>
            </div>
          </div>
        </div>
      </div>

      {/* Result Overlay */}
      <AnimatePresence>
        {showResult && (
          <div className="fixed inset-0 z-[60] flex items-center justify-center p-4 bg-slate-900/80 backdrop-blur-md">
            <motion.div 
               initial={{ scale: 0.9, opacity: 0, y: 20 }}
               animate={{ scale: 1, opacity: 1, y: 0 }}
               className="bg-white rounded-[2.5rem] p-10 max-w-md w-full text-center shadow-2xl border border-gray-100"
            >
               <div className="w-24 h-24 bg-yellow-400 rounded-full flex items-center justify-center mx-auto mb-6 shadow-xl shadow-yellow-100">
                 <Trophy className="w-12 h-12 text-white" />
               </div>
               <h2 className="text-4xl font-black text-gray-800 mb-2 italic uppercase">Misi Selesai!</h2>
               <p className="text-gray-500 mb-8 font-medium italic">"Kodemu rapi dan luar biasa! Teruskan bakatmu!"</p>
               
               <div className="bg-brand-light rounded-3xl p-8 mb-8 border border-brand/10">
                  <p className="text-[10px] font-black text-brand uppercase tracking-widest mb-1">Poin yang Didapat</p>
                  <p className="text-6xl font-black text-brand font-mono">+{earnedPoints}</p>
               </div>

               <div className="flex flex-col gap-3">
                  <button 
                    onClick={() => navigate('/portfolio')}
                    className="w-full bg-brand hover:bg-brand-dark text-white font-black py-4 rounded-2xl shadow-xl shadow-brand-light transition-all flex items-center justify-center gap-2 uppercase tracking-widest text-xs border border-accent-yellow"
                  >
                    🚀 Masuk ke Portfolio
                  </button>
                  <button 
                    onClick={() => navigate('/misi')}
                    className="w-full bg-slate-100 hover:bg-slate-200 text-slate-500 font-black py-4 rounded-2xl transition-all uppercase tracking-widest text-[10px]"
                  >
                    Kembali ke Daftar Misi
                  </button>
               </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>
    </div>
  );
};

export default MisiDetail;
