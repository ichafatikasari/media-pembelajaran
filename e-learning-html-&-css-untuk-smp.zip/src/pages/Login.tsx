import React, { useState } from 'react';
import { useNavigate, Navigate } from 'react-router-dom';
import { useStore } from '../store/useStore';
import { Eye, EyeOff, Lock, User, AlertCircle } from 'lucide-react';
import { motion } from 'motion/react';

const Login: React.FC = () => {
  const [displayName, setDisplayName] = useState('');
  const [password, setPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [error, setError] = useState('');
  const [showErrorModal, setShowErrorModal] = useState(false);
  
  const login = useStore((state) => state.login);
  const user = useStore((state) => state.user);
  const navigate = useNavigate();

  if (user?.loggedIn) {
    return <Navigate to="/beranda" replace />;
  }

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const success = login(displayName, password);
    if (success) {
      navigate('/beranda');
    } else {
      setError('Kode akses (password) salah atau nama masih kosong.');
      setShowErrorModal(true);
    }
  };

  return (
    <div className="min-h-screen bg-brand flex items-center justify-center p-4 border-4 border-accent-yellow">
      <motion.div 
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="bg-white rounded-3xl shadow-2xl p-8 w-full max-w-md"
      >
        <div className="text-center mb-8">
          <div className="bg-brand-light w-20 h-20 rounded-full flex items-center justify-center mx-auto mb-4">
             <span className="text-4xl">🚀</span>
          </div>
          <h1 className="text-3xl font-bold text-gray-800">E-Learning</h1>
          <p className="text-gray-500 font-medium font-mono">Halaman Belajar HTML & CSS</p>
        </div>

        <form onSubmit={handleSubmit} className="space-y-6">
          <div>
            <label className="block text-sm font-semibold text-gray-700 mb-2">Nama Panggilan</label>
            <div className="relative">
              <User className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400 w-5 h-5" />
              <input 
                type="text" 
                value={displayName}
                onChange={(e) => setDisplayName(e.target.value)}
                className="w-full pl-11 pr-4 py-3 bg-gray-50 border border-gray-200 rounded-xl focus:ring-2 focus:ring-brand focus:border-transparent outline-none transition-all"
                placeholder="Masukkan nama panggilanmu"
                required
              />
            </div>
          </div>

          <div>
            <label className="block text-sm font-semibold text-gray-700 mb-2">Kode Akses Kelas</label>
            <div className="relative">
              <Lock className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400 w-5 h-5" />
              <input 
                type={showPassword ? 'text' : 'password'}
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                className="w-full pl-11 pr-12 py-3 bg-gray-50 border border-gray-200 rounded-xl focus:ring-2 focus:ring-brand focus:border-transparent outline-none transition-all"
                placeholder="Masukkan password dari bapak/ibu guru"
                required
              />
              <button 
                type="button" 
                onClick={() => setShowPassword(!showPassword)}
                className="absolute right-3 top-1/2 -translate-y-1/2 text-gray-400 hover:text-brand"
              >
                {showPassword ? <EyeOff className="w-5 h-5" /> : <Eye className="w-5 h-5" />}
              </button>
            </div>
          </div>

          <button 
            type="submit" 
            className="w-full bg-brand hover:bg-brand-dark text-white font-bold py-3 rounded-xl shadow-lg shadow-brand-light border border-accent-yellow transition-all transform active:scale-95"
          >
            Masuk Sekarang
          </button>
        </form>

        <p className="text-center text-xs text-gray-400 mt-8">
          Ditujukan untuk Siswa SMP/MTs • Belajar Coding Seru!
        </p>
      </motion.div>

      {/* Error Modal */}
      {showErrorModal && (
        <div className="fixed inset-0 bg-black/50 flex items-center justify-center p-4 z-50">
          <motion.div 
            initial={{ scale: 0.9, opacity: 0 }}
            animate={{ scale: 1, opacity: 1 }}
            className="bg-white rounded-2xl p-6 max-w-sm w-full text-center"
          >
            <div className="bg-red-100 w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-4 text-red-600">
              <AlertCircle className="w-8 h-8" />
            </div>
            <h3 className="text-xl font-bold text-gray-800 mb-2">Login Gagal!</h3>
            <p className="text-gray-600 mb-6">{error}</p>
            <button 
              onClick={() => setShowErrorModal(false)}
              className="w-full bg-gray-800 text-white font-bold py-2 rounded-lg hover:bg-gray-900 transition-colors"
            >
              Tutup
            </button>
          </motion.div>
        </div>
      )}
    </div>
  );
};

export default Login;
