import React, { useState } from 'react';
import { useStore } from '../store/useStore';
import { 
  Users, 
  Search, 
  ChevronRight, 
  Trophy, 
  Target, 
  BookOpen, 
  Code2, 
  Calendar,
  Gamepad2,
  ArrowLeft,
  RefreshCw,
  Trash2
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { missions } from '../data/missions';
import { Navigate } from 'react-router-dom';

const TeacherPanel: React.FC = () => {
  const user = useStore((state) => state.user);
  const usersData = useStore((state) => state.usersData);
  const resetAllData = useStore((state) => state.resetAllData);
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedStudent, setSelectedStudent] = useState<string | null>(null);
  const [showResetConfirm, setShowResetConfirm] = useState(false);

  // Security check: Only guru can access
  if (!user || user.role !== 'guru') {
    return <Navigate to="/beranda" replace />;
  }

  const studentList = Object.entries(usersData)
    .filter(([username, data]) => {
      if (data.role === 'guru') return false;
      const name = data.displayName || username;
      return name.toLowerCase().includes(searchTerm.toLowerCase());
    })
    .map(([username, data]) => {
      const missionCount = Object.keys(data.missionsProgress || {}).length;
      const totalPoints = 
        Object.values(data.missionsProgress || {}).reduce((acc, curr) => acc + curr.score, 0) +
        (data.gameScores?.tagPop || 0) + 
        (data.gameScores?.cssPainter || 0) + 
        (data.gameScores?.tagBuilder || 0);

      return {
        username,
        displayName: data.displayName || username.replace(/_/g, ' ').toUpperCase(),
        missionCount,
        totalPoints,
        data
      };
    })
    .sort((a, b) => b.totalPoints - a.totalPoints);

  const currentStudent = selectedStudent ? {
    id: selectedStudent,
    ...usersData[selectedStudent]
  } : null;

  return (
    <div className="max-w-7xl mx-auto px-4 py-8">
      <header className="mb-8">
        <h1 className="text-3xl font-black text-gray-900 italic uppercase flex items-center gap-3">
          <Users className="w-8 h-8 text-brand" />
          Panel Monitoring Guru
        </h1>
        <p className="text-gray-500 font-medium">Pantau progres belajar dan hasil karya siswamu di sini.</p>
      </header>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
        {/* Student List Sidebar */}
        <div className="lg:col-span-4 space-y-6">
          <div className="relative">
            <Search className="absolute left-4 top-1/2 -translate-y-1/2 text-gray-400 w-5 h-5" />
            <input 
              type="text"
              placeholder="Cari nama siswa..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="w-full pl-12 pr-4 py-4 bg-white border border-gray-100 rounded-[2rem] shadow-sm focus:ring-2 focus:ring-brand focus:outline-none font-bold"
            />
          </div>

          <div className="bg-white rounded-[2.5rem] border border-gray-100 shadow-xl overflow-hidden">
            <div className="p-6 border-b border-gray-50 bg-gray-50/50">
               <h3 className="font-black text-[10px] uppercase tracking-widest text-gray-400">Daftar Siswa ({studentList.length})</h3>
            </div>
            <div className="divide-y divide-gray-50 max-h-[600px] overflow-y-auto">
              {studentList.length > 0 ? (
                studentList.map((student) => (
                  <button
                    key={student.username}
                    onClick={() => setSelectedStudent(student.username)}
                    className={`w-full p-6 flex items-center justify-between transition-all hover:bg-brand-light/50 ${selectedStudent === student.username ? 'bg-brand-light' : ''}`}
                  >
                    <div className="flex items-center gap-4 text-left">
                      <div className="w-12 h-12 rounded-2xl bg-brand border border-accent-yellow flex items-center justify-center text-white font-black">
                        {student.displayName.charAt(0)}
                      </div>
                      <div>
                        <h4 className="font-bold text-gray-900">{student.displayName}</h4>
                        <p className="text-xs text-gray-400 font-medium">{student.missionCount} Misi Selesai • {student.totalPoints} Poin</p>
                      </div>
                    </div>
                    <ChevronRight className={`w-5 h-5 ${selectedStudent === student.username ? 'text-brand' : 'text-gray-300'}`} />
                  </button>
                ))
              ) : (
                <div className="p-12 text-center text-gray-400 font-medium italic">
                  Belum ada siswa yang terdaftar.
                </div>
              )}
            </div>
          </div>

          {/* Reset Action */}
          <div className="bg-red-50 rounded-[2.5rem] border border-red-100 p-6">
             <h3 className="font-black text-[10px] uppercase tracking-widest text-red-400 mb-4 flex items-center gap-2">
                <Trash2 size={12} /> Area Berbahaya
             </h3>
             <p className="text-xs text-red-600 font-medium mb-4">
                Gunakan fitur ini jika Ibu/Bapak ingin pindah kelas atau memulai sesi baru. Seluruh data siswa akan terhapus.
             </p>
             {!showResetConfirm ? (
               <button 
                 onClick={() => setShowResetConfirm(true)}
                 className="w-full py-3 bg-red-600 text-white rounded-2xl font-bold flex items-center justify-center gap-2 hover:bg-red-700 transition-colors shadow-lg shadow-red-200"
               >
                 <RefreshCw size={18} /> Reset Data Kelas
               </button>
             ) : (
               <div className="space-y-2">
                 <p className="text-[10px] font-black text-red-700 uppercase text-center">Yakin ingin menghapus semua data?</p>
                 <div className="flex gap-2">
                   <button 
                     onClick={() => {
                        resetAllData();
                        setShowResetConfirm(false);
                        setSelectedStudent(null);
                     }}
                     className="flex-1 py-3 bg-red-700 text-white rounded-xl font-bold text-sm"
                   >
                     Ya, Hapus
                   </button>
                   <button 
                     onClick={() => setShowResetConfirm(false)}
                     className="flex-1 py-3 bg-white border border-red-200 text-red-600 rounded-xl font-bold text-sm"
                   >
                     Batal
                   </button>
                 </div>
               </div>
             )}
          </div>
        </div>

        {/* Student Progress Detail */}
        <div className="lg:col-span-8">
          <AnimatePresence mode="wait">
            {currentStudent ? (
              <motion.div
                key={selectedStudent}
                initial={{ opacity: 0, x: 20 }}
                animate={{ opacity: 1, x: 0 }}
                exit={{ opacity: 0, x: -20 }}
                className="space-y-8"
              >
                {/* Stats Summary */}
                <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                  <div className="bg-white p-6 rounded-[2rem] border border-gray-100 shadow-lg shadow-brand/5">
                    <div className="w-10 h-10 bg-brand-light text-brand rounded-xl flex items-center justify-center mb-4">
                      <Trophy className="w-5 h-5" />
                    </div>
                    <p className="text-3xl font-black text-gray-900">
                      {(currentStudent.gameScores?.tagPop || 0) + 
                       (currentStudent.gameScores?.cssPainter || 0) + 
                       (currentStudent.gameScores?.tagBuilder || 0) + 
                       Object.values(currentStudent.missionsProgress || {}).reduce((acc, curr) => acc + curr.score, 0)}
                    </p>
                    <p className="text-xs font-black text-gray-400 uppercase tracking-widest">Total Skor Kognitif</p>
                  </div>
                  <div className="bg-white p-6 rounded-[2rem] border border-gray-100 shadow-lg shadow-emerald-900/5">
                    <div className="w-10 h-10 bg-emerald-50 text-emerald-600 rounded-xl flex items-center justify-center mb-4">
                      <Target className="w-5 h-5" />
                    </div>
                    <p className="text-3xl font-black text-gray-900">
                      {Object.keys(currentStudent.missionsProgress || {}).length}
                    </p>
                    <p className="text-xs font-black text-gray-400 uppercase tracking-widest">Misi Praktik Selesai</p>
                  </div>
                  <div className="bg-white p-6 rounded-[2rem] border border-gray-100 shadow-lg shadow-orange-900/5">
                    <div className="w-10 h-10 bg-orange-50 text-orange-600 rounded-xl flex items-center justify-center mb-4">
                      <BookOpen className="w-5 h-5" />
                    </div>
                    <p className="text-3xl font-black text-gray-900">
                      {currentStudent.materiCompleted?.length || 0}
                    </p>
                    <p className="text-xs font-black text-gray-400 uppercase tracking-widest">Materi Dipelajari</p>
                  </div>
                </div>

                {/* Game Progress (Understanding) */}
                <div className="bg-white rounded-[2.5rem] border border-gray-100 shadow-xl p-8">
                  <h3 className="text-xl font-black text-gray-900 flex items-center gap-2 mb-6 italic uppercase">
                    <Gamepad2 className="text-orange-600" /> Analisa Pemahaman (Games)
                  </h3>
                  <div className="grid grid-cols-1 gap-4">
                    <div className="p-6 rounded-3xl bg-brand-light border border-brand/10 flex items-center justify-between">
                       <div>
                         <p className="text-[10px] font-black text-brand uppercase tracking-widest mb-1">Kemampuan Dasar HTML</p>
                         <h4 className="font-bold text-gray-900">Mengenal Tag HTML (Tag Pop)</h4>
                       </div>
                       <div className="text-right">
                         <p className="text-2xl font-black text-gray-900">{currentStudent.gameScores?.tagPop || 0}</p>
                         <p className="text-[10px] font-bold text-gray-400">Poin Kognitif</p>
                       </div>
                    </div>
                    <div className="p-6 rounded-3xl bg-indigo-50/50 border border-indigo-100 flex items-center justify-between">
                       <div>
                         <p className="text-[10px] font-black text-indigo-600 uppercase tracking-widest mb-1">Kemampuan Dasar CSS</p>
                         <h4 className="font-bold text-gray-900">Mewarnai & Styling (CSS Painter)</h4>
                       </div>
                       <div className="text-right">
                         <p className="text-2xl font-black text-gray-900">{currentStudent.gameScores?.cssPainter || 0}</p>
                         <p className="text-[10px] font-bold text-gray-400">Poin Kognitif</p>
                       </div>
                    </div>
                    <div className="p-6 rounded-3xl bg-purple-50/50 border border-purple-100 flex items-center justify-between">
                       <div>
                         <p className="text-[10px] font-black text-purple-600 uppercase tracking-widest mb-1">Gabungan HTML & CSS (Level Sulit)</p>
                         <h4 className="font-bold text-gray-900">Menyusun Struktur Kode (Tag Builder)</h4>
                       </div>
                       <div className="text-right">
                         <p className="text-2xl font-black text-gray-900">{currentStudent.gameScores?.tagBuilder || 0}</p>
                         <p className="text-[10px] font-bold text-gray-400">Poin Kognitif</p>
                       </div>
                    </div>
                  </div>
                </div>

                {/* Detail Missions */}
                <div className="bg-white rounded-[2.5rem] border border-gray-100 shadow-xl overflow-hidden p-8">
                  <h3 className="text-xl font-black text-gray-900 flex items-center gap-2 mb-6 italic uppercase">
                    <Code2 className="text-brand" /> Hasil Karya Coding
                  </h3>
                  
                  <div className="space-y-6">
                    {missions.map(misi => {
                      const progress = currentStudent.missionsProgress?.[misi.id];
                      return (
                        <div key={misi.id} className="p-6 rounded-3xl border border-gray-50 bg-gray-50/30 flex flex-col gap-4">
                          <div className="flex items-center justify-between">
                            <div className="flex items-center gap-3">
                              <div className={`w-8 h-8 rounded-lg flex items-center justify-center ${progress ? 'bg-emerald-500 text-white' : 'bg-gray-200 text-gray-400'}`}>
                                <Target size={16} />
                              </div>
                              <h4 className="font-bold text-gray-800">{misi.title}</h4>
                            </div>
                            <span className={`text-[10px] font-black uppercase px-3 py-1 rounded-full ${progress ? 'bg-emerald-50 text-emerald-600' : 'bg-gray-100 text-gray-400'}`}>
                              {progress ? 'Sudah Selesai' : 'Belum Selesai'}
                            </span>
                          </div>
                          
                          {progress && (
                            <div className="bg-slate-900 rounded-2xl p-4 overflow-hidden relative group">
                               <div className="absolute top-3 right-3 opacity-0 group-hover:opacity-100 transition-opacity">
                                  <span className="text-[10px] font-mono text-slate-500">Source: index.html</span>
                               </div>
                               <pre className="text-xs font-mono text-emerald-400 overflow-x-auto">
                                 {progress.code}
                               </pre>
                            </div>
                          )}
                        </div>
                      );
                    })}
                  </div>
                </div>
              </motion.div>
            ) : (
              <div className="h-full min-h-[400px] flex flex-col items-center justify-center text-center p-12 bg-white rounded-[2.5rem] border-2 border-dashed border-gray-100">
                <div className="w-20 h-20 bg-brand-light text-brand/50 rounded-full flex items-center justify-center mb-6">
                  <Users className="w-10 h-10" />
                </div>
                <h3 className="text-xl font-black text-gray-900 mb-2 uppercase italic">Pilih Siswa</h3>
                <p className="text-gray-400 font-medium max-w-xs">Silakan pilih salah satu siswa di daftar kiri untuk melihat laporan belajarnya.</p>
              </div>
            )}
          </AnimatePresence>
        </div>
      </div>
    </div>
  );
};

export default TeacherPanel;
