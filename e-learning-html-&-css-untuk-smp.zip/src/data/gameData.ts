export const validTags = [
  "<div>", "</div>", "<h1>", "</h1>", "<h2>", "</h2>", "<p>", "</p>", "<a>", "</a>", "<img>", "<span>", "</span>", "<br>"
];

export const invalidTags = [
  "<box>", "<text>", "<color>", "<font>", "<miau>", "<link>", "<bold>", "<italic>", "<web>", "<site>", "<gambar>"
];

export const cssPainterData = [
  {
    id: 1,
    property: "color",
    targetValue: "red",
    options: ["red", "blue", "green", "yellow"],
    question: "Ubah warna tulisan menjadi merah!"
  },
  {
    id: 2,
    property: "background-color",
    targetValue: "yellow",
    options: ["white", "yellow", "black", "pink"],
    question: "Ubah warna latar belakang menjadi kuning!"
  },
  {
    id: 3,
    property: "font-size",
    targetValue: "40px",
    options: ["10px", "20px", "30px", "40px"],
    question: "Perbesar ukuran teks menjadi 40px agar terlihat jelas!"
  },
  {
    id: 4,
    property: "border-radius",
    targetValue: "20px",
    options: ["0px", "5px", "10px", "20px"],
    question: "Buatlah sudut kotak menjadi agak bulat!"
  },
  {
    id: 5,
    property: "padding",
    targetValue: "30px",
    options: ["0px", "10px", "20px", "30px"],
    question: "Beri jarak dalam (padding) yang luas agar teks tidak sesak!"
  }
];

export const tagBuilderData = [
  {
    id: 1,
    goal: "Buatlah judul utama website menggunakan tag h1.",
    elements: ["<h1>", "Belajar Coding", "</h1>"],
    correctSequence: ["<h1>", "Belajar Coding", "</h1>"]
  },
  {
    id: 2,
    goal: "Buatlah sebuah paragraf sederhana.",
    elements: ["<p>", "HTML itu mudah!", "</p>"],
    correctSequence: ["<p>", "HTML itu mudah!", "</p>"]
  },
  {
    id: 3,
    goal: "Buatlah link menuju website Google.",
    elements: ["<a>", "Klik Google", "</a>"],
    correctSequence: ["<a>", "Klik Google", "</a>"]
  },
  {
    id: 4,
    goal: "Susun struktur: Kotak (div) yang berisi Judul (h2) di dalamnya.",
    elements: ["<div>", "<h2>", "Judul Kotak", "</h2>", "</div>"],
    correctSequence: ["<div>", "<h2>", "Judul Kotak", "</h2>", "</div>"]
  },
  {
    id: 5,
    goal: "Susun struktur: Paragraf (p) yang didalamnya ada Link (a).",
    elements: ["<p>", "Baca", "<a>", "di sini", "</a>", "</p>"],
    correctSequence: ["<p>", "Baca", "<a>", "di sini", "</a>", "</p>"]
  }
];
