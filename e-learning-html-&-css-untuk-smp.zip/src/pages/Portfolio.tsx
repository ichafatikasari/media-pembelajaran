import React, { useState } from 'react';
import { useStore } from '../store/useStore';
import { missions } from '../data/missions';
import { motion, AnimatePresence } from 'motion/react';
import { FolderSearch, Eye, Code, ExternalLink, Trash2, Calendar } from 'lucide-react';
import { cn } from '../lib/utils';

const Portfolio: React.FC = () => {
  const missionsProgress = useStore((state) => state.missionsProgress);
  const [selectedMisiId, setSelectedMisiId] = useState<string | null>(null);
  const [viewMode, setViewMode] = useState<'preview' | 'code'>('preview');

  const completedMissions = missions.filter(m => missionsProgress[m.id]?.completed);
  const activeMisi = missions.find(m => m.id === selectedMisiId);
  const activeProgress = selectedMisiId ? missionsProgress[selectedMisiId] : null;

  return (
    <div className="space-y-8">
      <div>
        <h1 className="text-3xl font-bold text-gray-800 flex items-center gap-3">
          <FolderSearch className="w-8 h-8 text-orange-500" /> Portofolio Karya
        </h1>
        <p className="text-gray-500">Kumpulan kode dan tampilan website yang sudah kamu buat.</p>
      </div>

      {completedMissions.length === 0 ? (
        <div className="bg-white rounded-3xl p-12 text-center border border-gray-100 shadow-sm max-w-2xl mx-auto">
           <div className="bg-gray-50 w-20 h-20 rounded-full flex items-center justify-center mx-auto mb-6 text-gray-300">
              <FolderSearch className="w-10 h-10" />
           </div>
           <h2 className="text-2xl font-bold text-gray-800">Portofolio Masih Kosong</h2>
           <p className="text-gray-500 mt-2 mb-8">Selesaikan misimu di menu Misi untuk memajang karyamu di sini!</p>
           <button 
             onClick={() => window.location.href = '/misi'}
             className="bg-brand hover:bg-brand-dark text-white font-bold px-8 py-3 rounded-2xl transition-all border border-accent-yellow"
           >
             Buka Menu Misi
           </button>
        </div>
      ) : (
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
          {/* List of Works */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4 auto-rows-max">
            {completedMissions.map((misi) => (
              <motion.button
                key={misi.id}
                whileHover={{ scale: 1.02 }}
                whileTap={{ scale: 0.98 }}
                onClick={() => {
                   setSelectedMisiId(misi.id);
                   setViewMode('preview');
                }}
                className={cn(
                  "flex flex-col text-left bg-white p-5 rounded-3xl border-2 transition-all",
                  selectedMisiId === misi.id 
                    ? "border-brand shadow-xl shadow-brand-light" 
                    : "border-gray-50 hover:border-gray-200"
                )}
              >
                <div className="bg-orange-100 text-orange-600 w-10 h-10 rounded-xl flex items-center justify-center mb-4">
                   <Code className="w-6 h-6" />
                </div>
                <h3 className="font-bold text-gray-800 line-clamp-1">{misi.title}</h3>
                <div className="flex items-center gap-2 mt-1 text-[10px] font-bold text-gray-400 uppercase tracking-widest">
                   <Calendar className="w-3 h-3" /> Selesai
                </div>
                <div className="mt-4 pt-4 border-t border-gray-50 flex items-center justify-between">
                   <span className="text-xs font-bold text-brand">Skor: {missionsProgress[misi.id]?.score}</span>
                   <div className="flex items-center gap-0.5 text-brand">
                      <Eye className="w-4 h-4" />
                   </div>
                </div>
              </motion.button>
            ))}
          </div>

          {/* Details Panel */}
          <div className="min-h-[500px]">
             {selectedMisiId ? (
                <div className="bg-white h-full rounded-[2.5rem] border border-gray-100 shadow-sm flex flex-col overflow-hidden">
                   <div className="p-6 border-b border-gray-50 flex items-center justify-between">
                      <div>
                         <h2 className="text-xl font-bold text-gray-800">{activeMisi?.title}</h2>
                         <p className="text-xs text-gray-400 font-medium">Tingkat {activeMisi?.level}</p>
                      </div>
                      <div className="flex bg-gray-100 p-1 rounded-xl">
                         <button 
                           onClick={() => setViewMode('preview')}
                           className={cn(
                             "px-4 py-1.5 rounded-lg text-xs font-bold transition-all",
                             viewMode === 'preview' ? "bg-white text-brand shadow-sm" : "text-gray-500 hover:text-gray-700"
                           )}
                         >
                            Tampilan
                         </button>
                         <button 
                           onClick={() => setViewMode('code')}
                           className={cn(
                             "px-4 py-1.5 rounded-lg text-xs font-bold transition-all",
                             viewMode === 'code' ? "bg-white text-brand shadow-sm" : "text-gray-500 hover:text-gray-700"
                           )}
                         >
                            Kode
                         </button>
                      </div>
                   </div>

                   <div className="flex-1 bg-gray-50 relative">
                      {viewMode === 'preview' ? (
                         <iframe 
                           title="portfolio-preview"
                           srcDoc={activeProgress?.code || ''}
                           className="w-full h-full border-0 bg-white"
                         />
                      ) : (
                         <pre className="p-6 font-mono text-sm text-gray-700 whitespace-pre-wrap overflow-auto max-h-[500px] custom-scrollbar">
                           <code>{activeProgress?.code}</code>
                         </pre>
                      )}
                   </div>
                   
                   <div className="p-4 bg-gray-50 border-t border-gray-100 text-center">
                       <p className="text-[10px] font-bold text-gray-400 uppercase tracking-widest">
                         Karya ini dibuat pada mode belajar {activeMisi?.topic}
                       </p>
                   </div>
                </div>
             ) : (
                <div className="h-full bg-brand-light rounded-[2.5rem] border-2 border-dashed border-brand/20 flex flex-col items-center justify-center p-8 text-center text-brand/50">
                   <Eye className="w-16 h-16 mb-4 opacity-30" />
                   <p className="font-bold">Pilih karya di sebelah kiri untuk melihat detailnya</p>
                </div>
             )}
          </div>
        </div>
      )}
    </div>
  );
};

export default Portfolio;
