import React from 'react';
import { NavLink, useNavigate } from 'react-router-dom';
import { useStore } from '../store/useStore';
import { 
  BookOpen, 
  Play, 
  Gamepad2, 
  Target, 
  FolderSearch, 
  Trophy, 
  LogOut, 
  User as UserIcon,
  Menu,
  X,
  Users
} from 'lucide-react';
import { useState } from 'react';

const Navbar: React.FC = () => {
  const user = useStore((state) => state.user);
  const logout = useStore((state) => state.logout);
  const navigate = useNavigate();
  const [isMenuOpen, setIsMenuOpen] = useState(false);

  const handleLogout = () => {
    logout();
    navigate('/login');
  };

  const navItems = [
    { name: 'Materi', path: '/materi', icon: BookOpen },
    { name: 'Video', path: '/video', icon: Play },
    { name: 'Game', path: '/game', icon: Gamepad2 },
    { name: 'Misi', path: '/misi', icon: Target },
    { name: 'Portfolio', path: '/portfolio', icon: FolderSearch },
    { name: 'Leaderboard', path: '/leaderboard', icon: Trophy },
  ];

  const filteredNavItems = user?.role === 'guru' 
    ? [
        { name: 'Materi', path: '/materi', icon: BookOpen },
        { name: 'Video', path: '/video', icon: Play },
        { name: 'Panel Guru', path: '/panel-guru', icon: Users }
      ]
    : navItems;

  return (
    <nav className="bg-white border-b border-gray-100 sticky top-0 z-40">
      <div className="max-w-7xl mx-auto px-4">
        <div className="flex justify-between h-16">
          <div className="flex items-center">
            <NavLink to="/beranda" className="flex items-center gap-2 group">
              <div className="bg-brand p-1.5 rounded-lg group-hover:rotate-12 transition-transform shadow-md border border-accent-yellow">
                <span className="text-white text-xl">🚀</span>
              </div>
              <span className="text-xl font-black text-brand tracking-tight flex items-center gap-1">
                E-Learn <span className="text-accent-yellow">Web</span>
              </span>
            </NavLink>
            
            <div className="hidden md:ml-8 md:flex md:space-x-4">
              {filteredNavItems.map((item) => (
                <NavLink
                  key={item.name}
                  to={item.path}
                  className={({ isActive }) => 
                    `flex items-center gap-2 px-3 py-2 rounded-xl text-sm font-semibold transition-colors ${
                      isActive 
                        ? 'bg-brand text-white shadow-sm' 
                        : 'text-gray-500 hover:bg-brand-light hover:text-brand'
                    }`
                  }
                >
                  <item.icon className="w-4 h-4" />
                  {item.name}
                </NavLink>
              ))}
            </div>
          </div>

          <div className="flex items-center gap-4">
            <div className="hidden md:flex items-center gap-2 bg-gray-50 px-3 py-1.5 rounded-full border border-gray-100">
              <UserIcon className="w-4 h-4 text-gray-400" />
              <span className="text-sm font-semibold text-gray-700">{user?.displayName}</span>
            </div>
            
            <button
              onClick={handleLogout}
              className="hidden md:flex items-center gap-2 text-gray-500 hover:text-red-500 transition-colors px-3 py-2 font-medium text-sm"
            >
              <LogOut className="w-4 h-4" />
              Keluar
            </button>

            {/* Mobile menu button */}
            <div className="md:hidden flex items-center">
              <button
                onClick={() => setIsMenuOpen(!isMenuOpen)}
                className="inline-flex items-center justify-center p-2 rounded-md text-gray-400 hover:text-brand hover:bg-brand-light focus:outline-none"
              >
                {isMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
              </button>
            </div>
          </div>
        </div>
      </div>

      {/* Mobile Menu */}
      {isMenuOpen && (
        <div className="md:hidden bg-white border-t border-gray-100 py-4 px-2 space-y-1">
          {filteredNavItems.map((item) => (
            <NavLink
              key={item.name}
              to={item.path}
              onClick={() => setIsMenuOpen(false)}
              className={({ isActive }) => 
                `flex items-center gap-3 px-4 py-3 rounded-xl text-base font-semibold transition-colors ${
                  isActive 
                    ? 'bg-brand text-white' 
                    : 'text-gray-500 hover:bg-brand-light hover:text-brand'
                }`
              }
            >
              <item.icon className="w-5 h-5" />
              {item.name}
            </NavLink>
          ))}
          <div className="border-t border-gray-100 my-2 pt-2 px-4">
            <div className="flex items-center gap-2 mb-4">
               <UserIcon className="w-4 h-4 text-gray-400" />
               <span className="text-sm font-semibold text-gray-700">{user?.displayName}</span>
            </div>
            <button
              onClick={handleLogout}
              className="w-full flex items-center gap-3 px-4 py-3 text-red-500 font-medium hover:bg-red-50 transition-colors rounded-xl"
            >
              <LogOut className="w-5 h-5" />
              Keluar
            </button>
          </div>
        </div>
      )}
    </nav>
  );
};

export default Navbar;
