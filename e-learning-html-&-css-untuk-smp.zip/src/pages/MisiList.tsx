import React from 'react';
import { motion } from 'motion/react';
import { Target, Lock, CheckCircle, ArrowRight, Star } from 'lucide-react';
import { Link } from 'react-router-dom';
import { missions } from '../data/missions';
import { useStore } from '../store/useStore';
import { cn } from '../lib/utils';

const MisiList: React.FC = () => {
  const missionsProgress = useStore((state) => state.missionsProgress);

  const isMissionUnlocked = (index: number) => {
    if (index === 0) return true;
    const prevMission = missions[index - 1];
    return missionsProgress[prevMission.id]?.completed;
  };

  return (
    <div className="space-y-8">
      <div>
        <h1 className="text-3xl font-bold text-gray-800 flex items-center gap-3">
          <Target className="w-8 h-8 text-red-500" /> Lembar Misi Coding
        </h1>
        <p className="text-gray-500">Selesaikan misi coding satu per satu untuk menjadi master web!</p>
      </div>

      <div className="max-w-4xl mx-auto space-y-6">
        {missions.map((misi, index) => {
          const isUnlocked = isMissionUnlocked(index);
          const isCompleted = missionsProgress[misi.id]?.completed;
          const score = missionsProgress[misi.id]?.score || 0;

          return (
            <motion.div
              key={misi.id}
              initial={{ opacity: 0, x: -20 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ delay: index * 0.1 }}
              className={cn(
                "relative bg-white rounded-3xl p-6 border-2 transition-all group overflow-hidden",
                isUnlocked 
                  ? "border-gray-100 hover:border-brand shadow-sm hover:shadow-xl hover:shadow-brand-light" 
                  : "border-gray-100 bg-gray-50/50 opacity-80"
              )}
            >
              <div className="flex flex-col md:flex-row md:items-center gap-6">
                {/* Status Icon */}
                <div className={cn(
                  "w-16 h-16 rounded-2xl flex items-center justify-center shrink-0 shadow-lg",
                  isCompleted 
                    ? "bg-green-500 text-white" 
                    : isUnlocked 
                      ? "bg-brand text-white border-2 border-accent-yellow" 
                      : "bg-gray-200 text-gray-400 shadow-none"
                )}>
                  {isCompleted ? <CheckCircle className="w-8 h-8" /> : isUnlocked ? <Target className="w-8 h-8" /> : <Lock className="w-8 h-8" />}
                </div>

                {/* Info */}
                <div className="flex-1">
                  <div className="flex flex-wrap items-center gap-2 mb-2">
                    <span className={cn(
                      "text-[10px] font-bold uppercase tracking-widest px-2 py-0.5 rounded-full border",
                      misi.difficulty === 'Mudah' ? "bg-green-50 text-green-600 border-green-100" :
                      misi.difficulty === 'Menengah' ? "bg-brand-light text-brand border-brand/10" :
                      "bg-purple-50 text-purple-600 border-purple-100"
                    )}>
                      {misi.difficulty}
                    </span>
                    <span className="text-[10px] font-bold text-gray-400 uppercase tracking-widest">
                       • {misi.topic}
                    </span>
                  </div>
                  <h3 className="text-xl font-bold text-gray-800">{misi.title}</h3>
                  <p className="text-gray-500 text-sm mt-1">{misi.instruction.substring(0, 80)}...</p>
                </div>

                {/* Score / Action */}
                <div className="flex flex-col md:items-end gap-3 min-w-[120px]">
                  {isCompleted ? (
                    <div className="text-center md:text-right">
                       <p className="text-[10px] font-bold text-gray-400 uppercase">Skor Kamu</p>
                       <p className="text-2xl font-black text-green-600">{score} <span className="text-sm font-bold text-gray-400">/ {misi.points}</span></p>
                    </div>
                  ) : isUnlocked ? (
                    <div className="text-center md:text-right">
                       <p className="text-[10px] font-bold text-gray-400 uppercase mb-1">Potensi Poin</p>
                       <div className="flex items-center justify-center md:justify-end gap-1 text-xl font-bold text-yellow-600">
                          <Star className="w-5 h-5 fill-current" /> {misi.points}
                       </div>
                    </div>
                  ) : null}

                  {isUnlocked && !isCompleted ? (
                    <Link
                      to={`/misi/${misi.id}`}
                      className="bg-brand hover:bg-brand-dark text-white font-bold px-6 py-3 rounded-2xl flex items-center justify-center gap-2 transition-all active:scale-95 shadow-lg shadow-brand-light border border-accent-yellow"
                    >
                      Kerjakan <ArrowRight className="w-4 h-4" />
                    </Link>
                  ) : !isUnlocked ? (
                    <div className="flex items-center justify-center gap-2 text-gray-400 font-bold py-3">
                       <Lock className="w-4 h-4" /> Terkunci
                    </div>
                  ) : (
                    <div className="flex items-center justify-center gap-2 text-green-600 font-bold py-3 bg-green-50 rounded-2xl border border-green-100">
                       <CheckCircle className="w-4 h-4" /> Selesai
                    </div>
                  )}
                </div>
              </div>

              {!isUnlocked && (
                <div className="mt-4 pt-4 border-t border-gray-100 flex items-center gap-2 text-xs text-gray-400 italic">
                  <Lock className="w-3 h-3 text-gray-300" /> 
                  Selesaikan misi sebelumnya untuk membuka ini.
                </div>
              )}
            </motion.div>
          );
        })}
      </div>

      <div className="bg-amber-100/50 p-8 rounded-[2.5rem] border-2 border-dashed border-amber-200 flex flex-col items-center text-center gap-4">
         <div className="bg-white w-16 h-16 rounded-full flex items-center justify-center shadow-md">
            <Target className="w-8 h-8 text-amber-500" />
         </div>
         <div>
           <h4 className="text-xl font-bold text-amber-900">Aturan Misi</h4>
           <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mt-4 text-left max-w-2xl mx-auto">
              <div className="bg-white/60 p-4 rounded-2xl space-y-1">
                 <p className="font-bold text-amber-800 text-sm">💡 Sekali Kerjakan</p>
                 <p className="text-xs text-amber-900/70">Misi yang sudah dikirim tidak bisa diulang untuk meningkatkan skor. Hati-hati!</p>
              </div>
              <div className="bg-white/60 p-4 rounded-2xl space-y-1">
                 <p className="font-bold text-amber-800 text-sm">💯 Penilaian Otomatis</p>
                 <p className="text-xs text-amber-900/70">Sistem akan mengecek kodemu secara otomatis berdasarkan kriteria yang diberikan.</p>
              </div>
           </div>
         </div>
      </div>
    </div>
  );
};

export default MisiList;
