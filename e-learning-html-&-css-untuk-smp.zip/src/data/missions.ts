export const missions = [
  {
    id: "misi-1",
    title: "Menyapa Dunia",
    difficulty: "Mudah",
    level: 1,
    category: "HTML",
    topic: "Dasar HTML",
    instruction: "Gunakan tag <h1> untuk membuat tulisan besar yang menyapa dunia! Ketik <h1>Halo Dunia!</h1> agar websitemu punya judul yang keren.",
    initialHtml: "<!-- Ketik kode di bawah ini -->\n",
    initialCss: "/* Biarkan kosong jika tidak diperlukan */",
    sampleImageUrl: "",
    mission: "Buat elemen heading utama (h1) dengan teks 'Halo Dunia!'.",
    checks: [
      { id: 1, text: "Menggunakan tag <h1>", regex: /<h1>/i, isCss: false },
      { id: 2, text: "Terdapat teks 'Halo Dunia!'", regex: /Halo Dunia!/i, isCss: false },
      { id: 3, text: "Tag penutup </h1>", regex: /<\/h1>/i, isCss: false }
    ],
    points: 100
  },
  {
    id: "misi-2",
    title: "Rumah Paragraf",
    difficulty: "Mudah",
    level: 2,
    category: "HTML",
    topic: "Dasar HTML",
    instruction: "Buatlah sebuah paragraf menggunakan tag <p> yang berisi nama lengkapmu. Contoh: <p>Nama saya adalah Budi.</p>",
    initialHtml: "<h1>Profil Saya</h1>\n",
    initialCss: "",
    sampleImageUrl: "",
    mission: "Tambahkan paragraf (p) di bawah heading yang sudah ada.",
    checks: [
      { id: 1, text: "Tetap ada tag <h1>", regex: /<h1>/i, isCss: false },
      { id: 2, text: "Menggunakan tag <p>", regex: /<p>/i, isCss: false },
      { id: 3, text: "Tag penutup </p>", regex: /<\/p>/i, isCss: false }
    ],
    points: 100
  },
  {
    id: "misi-3",
    title: "Mewarnai Judul",
    difficulty: "Menengah",
    level: 3,
    category: "CSS",
    topic: "Dasar CSS",
    instruction: "Waktunya CSS! Ubah warna tulisan <h1> menjadi biru (blue) menggunakan selector CSS. Tulis h1 { color: blue; } di bagian CSS.",
    initialHtml: "<h1>Judul Berwarna</h1>",
    initialCss: "/* Ubah warna h1 di sini */\n",
    sampleImageUrl: "",
    mission: "Gunakan CSS selector untuk mewarnai teks heading menjadi biru.",
    checks: [
      { id: 1, text: "Menggunakan selector h1", regex: /h1\s*{/i, isCss: true },
      { id: 2, text: "Properti color bernilai blue", regex: /color:\s*blue/i, isCss: true },
      { id: 3, text: "Tag <h1> tetap ada di HTML", regex: /<h1>/i, isCss: false }
    ],
    points: 150
  },
  {
    id: "misi-4",
    title: "Tombol Cantik",
    difficulty: "Menengah",
    level: 4,
    category: "CSS",
    topic: "Dasar CSS",
    instruction: "Hias tombolmu! Di bagian CSS, tambahkan properti: padding: 20px; dan background-color: yellow; agar tombol terlihat besar dan berwarna kuning. Tips: Gunakan selector button { ... }",
    initialHtml: "<button>Klik Saya</button>",
    initialCss: "button {\n  /* Tambahkan style di sini */\n}\n",
    sampleImageUrl: "",
    mission: "Dekorasi tombol HTML menggunakan CSS agar lebih menarik.",
    checks: [
      { id: 1, text: "Ada padding (misal 20px)", regex: /padding:\s*20px/i, isCss: true },
      { id: 2, text: "Latar kuning (yellow)", regex: /(background-color|background):\s*yellow/i, isCss: true },
      { id: 3, text: "Selector button digunakan", regex: /button\s*{/i, isCss: true }
    ],
    points: 150
  },
  {
    id: "misi-5",
    title: "Kartu Profil",
    difficulty: "Sulit",
    level: 5,
    category: "CSS",
    topic: "Layout Dasar",
    instruction: "Tantangan Terakhir! Di bagian CSS, hias class .card. Berikan style: background-color: lightblue; padding: 20px; border-radius: 15px;.",
    initialHtml: "<div class=\"card\">\n  <h2>Nama Saya</h2>\n  <p>Saya adalah calon programmer.</p>\n</div>",
    initialCss: ".card {\n  /* Buat kartu di sini */\n}\n",
    sampleImageUrl: "",
    mission: "Gabungkan semua pengetahuan untuk membuat komponen UI kartu profil.",
    checks: [
      { id: 1, text: "Latar berwarna lightblue", regex: /(background-color|background):\s*lightblue/i, isCss: true },
      { id: 2, text: "Ada padding 20px", regex: /padding:\s*20px/i, isCss: true },
      { id: 3, text: "Ada border-radius 15px", regex: /border-radius:\s*15px/i, isCss: true }
    ],
    points: 500
  }
];
