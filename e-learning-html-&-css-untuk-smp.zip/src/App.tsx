import React from 'react';
import { BrowserRouter, Routes, Route, Navigate } from 'react-router-dom';
import ScrollToTop from './components/ScrollToTop';
import Login from './pages/Login';
import ProtectedRoute from './components/ProtectedRoute';
import Layout from './components/Layout';
import Beranda from './pages/Beranda';
import Materi from './pages/Materi';
import Video from './pages/Video';
import GameList from './pages/GameList';
import TagPop from './games/TagPop';
import CSSPainter from './games/CSSPainter';
import TagBuilder from './games/TagBuilder';
import MisiList from './pages/MisiList';
import MisiDetail from './pages/MisiDetail';
import Portfolio from './pages/Portfolio';
import Leaderboard from './pages/Leaderboard';
import TeacherPanel from './pages/TeacherPanel';

// Games
export default function App() {
  return (
    <BrowserRouter>
      <ScrollToTop />
      <Routes>
        <Route path="/login" element={<Login />} />
        
        <Route element={<ProtectedRoute><Layout /></ProtectedRoute>}>
          <Route path="/beranda" element={<Beranda />} />
          <Route path="/materi" element={<Materi />} />
          <Route path="/video" element={<Video />} />
          <Route path="/game" element={<GameList />} />
          <Route path="/game/tag-pop" element={<TagPop />} />
          <Route path="/game/css-painter" element={<CSSPainter />} />
          <Route path="/game/tag-builder" element={<TagBuilder />} />
          <Route path="/misi" element={<MisiList />} />
          <Route path="/misi/:id" element={<MisiDetail />} />
          <Route path="/portfolio" element={<Portfolio />} />
          <Route path="/leaderboard" element={<Leaderboard />} />
          <Route path="/panel-guru" element={<TeacherPanel />} />
          <Route path="/" element={<Navigate to="/beranda" replace />} />
        </Route>

        <Route path="*" element={<Navigate to="/beranda" replace />} />
      </Routes>
    </BrowserRouter>
  );
}
