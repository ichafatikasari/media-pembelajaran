import React from 'react';
import { useStore } from '../store/useStore';
import { motion } from 'motion/react';
import { 
  BookOpen, 
  Play, 
  Gamepad2, 
  Target, 
  FolderSearch, 
  Trophy,
  ArrowRight,
  Target as TargetIcon,
  Star,
  Award
} from 'lucide-react';
import { Link } from 'react-router-dom';

const Beranda: React.FC = () => {
  const user = useStore((state) => state.user);
  const getTotalPoints = useStore((state) => state.getTotalPoints);
  const missionsProgress = useStore((state) => state.missionsProgress);
  const completedMateri = useStore((state) => state.materiCompleted);

  const totalPoints = getTotalPoints();
  const completedMissionsCount = Object.values(missionsProgress).filter(m => m.completed).length;

  const initialMenus = [
    { name: 'Materi', path: '/materi', icon: BookOpen, color: 'bg-brand', desc: 'Belajar konsep dasar HTML & CSS' },
    { name: 'Video', path: '/video', icon: Play, color: 'bg-purple-600', desc: 'Tonton video tutorial menarik' },
    { name: 'Game', path: '/game', icon: Gamepad2, color: 'bg-teal-600', desc: 'Bermain sambil mengasah logika' },
    { name: 'Misi', path: '/misi', icon: Target, color: 'bg-red-500', desc: 'Uji kemampuan coding kamu' },
    { name: 'Portfolio', path: '/portfolio', icon: FolderSearch, color: 'bg-orange-500', desc: 'Lihat hasil karya codingmu' },
    { name: 'Leaderboard', path: '/leaderboard', icon: Trophy, color: 'bg-accent-yellow text-slate-950', desc: 'Lihat peringkat teman-temanmu' },
  ];

  const menus = user?.role === 'guru'
    ? [
        { name: 'Materi', path: '/materi', icon: BookOpen, color: 'bg-brand', desc: 'Lihat materi pembelajaran' },
        { name: 'Video', path: '/video', icon: Play, color: 'bg-purple-600', desc: 'Tonton video tutorial' },
        { name: 'Panel Guru', path: '/panel-guru', icon: Target, color: 'bg-emerald-600', desc: 'Pantau progres belajar siswa' },
      ]
    : initialMenus;

  const container = {
    hidden: { opacity: 0 },
    show: {
      opacity: 1,
      transition: {
        staggerChildren: 0.1
      }
    }
  };

  const item = {
    hidden: { y: 20, opacity: 0 },
    show: { y: 0, opacity: 1 }
  };

  return (
    <div className="space-y-8 pb-12">
      {/* Welcome Section */}
      <section className="bg-brand rounded-3xl p-8 text-white shadow-xl relative overflow-hidden border-2 border-accent-yellow">
        <div className="relative z-10 flex flex-col md:flex-row md:items-center justify-between gap-6">
          <div>
            <h1 className="text-3xl md:text-4xl font-black mb-2">Halo, {user?.displayName}! 👋</h1>
            <p className="text-brand-light text-lg max-w-md font-medium">
              Siap untuk melanjutkan petualangan coding kamu hari ini? Latih terus kemampuanmu!
            </p>
          </div>
          {user?.role === 'siswa' && (
            <div className="flex gap-4">
              <div className="bg-white/20 backdrop-blur-md p-4 rounded-2xl border border-white/30 text-center min-w-[100px]">
                <p className="text-sm font-medium text-brand-light uppercase tracking-wider mb-1">Misi Selesai</p>
                <p className="text-3xl font-bold">{completedMissionsCount}/3</p>
              </div>
              <div className="bg-white/20 backdrop-blur-md p-4 rounded-2xl border border-white/30 text-center min-w-[100px]">
                <p className="text-sm font-medium text-brand-light uppercase tracking-wider mb-1">Total Poin</p>
                <p className="text-3xl font-bold text-accent-yellow">{totalPoints}</p>
              </div>
            </div>
          )}
          {user?.role === 'guru' && (
            <div className="bg-white/20 backdrop-blur-md p-6 rounded-2xl border border-white/30 text-center">
              <p className="text-sm font-medium text-brand-light uppercase tracking-wider mb-1">Mode Guru</p>
              <p className="text-3xl font-bold text-accent-yellow">Aktif 🎓</p>
            </div>
          )}
        </div>
        
        {/* Decorative Circles */}
        <div className="absolute -right-20 -bottom-20 w-64 h-64 bg-white/10 rounded-full blur-3xl"></div>
        <div className="absolute -left-10 -top-10 w-48 h-48 bg-white/10 rounded-full blur-3xl"></div>
      </section>

      {/* Progress Cards */}
      {user?.role === 'siswa' && (
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          <div className="bg-white p-6 rounded-2xl border border-gray-100 shadow-sm flex items-center gap-4">
            <div className="p-3 bg-yellow-100 text-yellow-600 rounded-xl">
               <Star className="w-6 h-6 fill-current text-accent-yellow" />
            </div>
            <div>
               <p className="text-gray-500 text-sm font-medium">Badge Koleksi</p>
               <p className="text-lg font-bold text-gray-800">
                  {totalPoints >= 100 ? 'Pemula Hebat' : 'Calon Coder'}
               </p>
            </div>
          </div>
          <div className="bg-white p-6 rounded-2xl border border-gray-100 shadow-sm flex items-center gap-4">
            <div className="p-3 bg-brand-light text-brand rounded-xl">
               <TargetIcon className="w-6 h-6" />
            </div>
            <div>
               <p className="text-gray-500 text-sm font-medium">Materi Dibaca</p>
               <p className="text-lg font-bold text-gray-800">{completedMateri.length} Topik</p>
            </div>
          </div>
          <div className="bg-white p-6 rounded-2xl border border-gray-100 shadow-sm flex items-center gap-4">
            <div className="p-3 bg-purple-100 text-purple-600 rounded-xl">
               <Award className="w-6 h-6" />
            </div>
            <div>
               <p className="text-gray-500 text-sm font-medium">Status Akun</p>
               <p className="text-lg font-bold text-gray-800">Siswa Aktif</p>
            </div>
          </div>
        </div>
      )}

      {/* Quick Menu Grid */}
      <div>
        <h2 className="text-2xl font-bold text-gray-800 mb-6 flex items-center gap-2">
          Mau Belajar Apa?
        </h2>
        <motion.div 
          variants={container}
          initial="hidden"
          animate="show"
          className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6"
        >
          {menus.map((menu) => (
            <motion.div key={menu.name} variants={item}>
              <Link 
                to={menu.path}
                className="group block bg-white hover:bg-gray-50 p-6 rounded-3xl border-2 border-gray-100 hover:border-brand transition-all shadow-sm hover:shadow-xl hover:shadow-brand-light"
              >
                <div className="flex justify-between items-start mb-4">
                  <div className={`${menu.color} p-4 rounded-2xl text-white shadow-lg`}>
                    <menu.icon className="w-6 h-6" />
                  </div>
                  <ArrowRight className="w-5 h-5 text-gray-300 group-hover:text-brand-dark group-hover:translate-x-1 transition-all" />
                </div>
                <h3 className="text-xl font-bold text-gray-800 mb-1">{menu.name}</h3>
                <p className="text-gray-500 text-sm">{menu.desc}</p>
              </Link>
            </motion.div>
          ))}
        </motion.div>
      </div>
    </div>
  );
};

export default Beranda;
