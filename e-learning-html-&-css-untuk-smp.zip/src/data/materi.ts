export const topics = [
  {
    id: "web-website",
    title: "Web dan Website",
    shortDesc: "Bagaimana sih cara website bekerja di internet?",
    description: "Bayangkan website itu seperti sebuah 'Rumah Digital' di jalan raya besar bernama Internet. \n\nSetiap rumah punya alamat khusus (seperti google.com) agar orang-orang di seluruh dunia bisa berkunjung. Di dalam rumah digital ini, kamu bisa memajang tulisan, foto kegiatan, atau bahkan video hobi kesukaanmu sendiri!",
    analogy: "Website itu seperti mading (majalah dinding) sekolah, tapi versi digitalnya yang bisa diakses pakai HP atau Laptop saja.",
    highlight: "Website adalah wadah seru untuk membagikan informasi secara online!",
    example: "Contoh Alamat Website:\n- www.youtube.com\n- www.wikipedia.org"
  },
  {
    id: "browser",
    title: "Apa itu Browser?",
    shortDesc: "Si penerjemah kode rahasia menjadi tampilan keren.",
    description: "Browser adalah aplikasi pahlawan kita! Mengapa? Karena aslinya website ditulis dalam bentuk 'bahasa kode rahasia' komputer yang sangat sulit dipahami oleh mata manusia biasa.\n\nBrowser bertugas membantu kita menerjemahkan kode rahasia tersebut menjadi tampilan indah yang penuh dengan warna-warni, gambar lucu, dan tombol pintar yang bisa diklik.",
    analogy: "Browser itu seperti 'Kacamata Penerjemah'. Tanpa kacamata ini, website cuma terlihat sebagai barisan tulisan komputer yang pusing dan membosankan.",
    highlight: "Browser yang sering kita pakai sehari-hari adalah Google Chrome, Safari, dan Firefox!",
    example: "Nama-Nama Browser:\n- Google Chrome\n- Mozilla Firefox\n- Safari"
  },
  {
    id: "html-dasar",
    title: "HTML: Kerangka Web",
    shortDesc: "Belajar membuat pondasi website milikmu sendiri.",
    description: "HTML adalah bahasa dasar yang digunakan untuk menentukan bagian-bagian pada sebuah website.\n\nBagian utama dari HTML biasanya ditulis berpasangan:\n1. **Tag Pembuka** - Menandakan awal dari tulisan atau tombol, contohnya <p>.\n2. **Isi** - Tulisan atau konten yang diletakkan di dalam tag tersebut.\n3. **Tag Penutup** - Menandakan akhir dari tulisan tersebut, ditandai dengan garis miring tambahan, contohnya </p>.\n\nBerikut beberapa tag penting dalam HTML yang sering dipakai:\n- **h1 sampai h6** - Digunakan untuk membuat judul tulisan. h1 adalah judul paling besar, sedangkan h6 yang paling kecil.\n- **p** - Digunakan untuk menulis paragraf atau teks cerita biasa.\n- **img** - Digunakan untuk menampilkan gambar atau foto seru. Tag ini spesial karena tidak membutuhkan tag penutup!\n- **a** - Digunakan untuk menghubungkan halaman atau membuat tombol link yang bisa diklik.\n- **div** - Berperan sebagai kotak pembungkus yang membantu kita mengelompokkan elemen halaman agar rapi.\n- **br** - Berfungsi untuk ganti baris tulisan ke bawah (seperti memencet tombol Enter).\n- **span** - Berfungsi menandai beberapa huruf atau kata kecil di dalam tulisan agar bisa dihias secara khusus.",
    analogy: "HTML itu seperti 'Kerangka Manusia' atau 'Brick Lego'. Belum ada warna-warninya, tapi bentuk dasarnya sudah terlihat jelas.",
    highlight: "Gunakan tag pembuka dan penutup secara berpasangan agar websitemu dapat dibaca sempurna oleh browser!",
    example: "<!-- Contoh Kode HTML -->\n<!-- Tag Pembuka + Isi + Tag Penutup -->\n<h1>Judul Utama Website Saya</h1>\n<p>Saya sedang belajar membuat website.</p>\n\n<br> <!-- Membuat baris baru -->\n\n<div>\n  <a href='https://google.com'>Pergi ke Google</a>\n  <br>\n  <img src='kucing_lucu.jpg' alt='Foto Kucing'>\n</div>"
  },
  {
    id: "css-dasar",
    title: "CSS: Baju Website",
    shortDesc: "Waktunya dandan! Hias websitemu sesuka hati.",
    description: "Setelah kerangka rumah (HTML) selesai dibuat, saatnya kita hias dan dandan menggunakan CSS!\n\nBerikut konsep dan properti dekorasi penting di dalam CSS:\n\n1. **CSS Selector** - Cara untuk memilih bagian HTML mana saja yang ingin dihias. Contohnya, menggunakan kata button untuk menghias semua tombol, atau kata .kotak untuk menghias elemen dengan nama kelas kotak.\n2. **color** - Mengatur warna dari tulisan atau huruf.\n3. **padding** - Memberikan ruang kosong di dalam bagian kotak agar tulisan tidak terasa menempel sempit ke sekeliling batas tepi.\n4. **background-color** - Mewarnai latar belakang suatu kotak atau halaman.\n5. **border-radius** - Membuat sudut dan siku-siku pada kotak menjadi tumpul melengkung indah.\n6. **font-size** - Memperbesar atau memperkecil ukuran huruf tulisan.",
    analogy: "Kalau HTML itu adalah badannya, maka CSS adalah 'Baju, Celana, Sepatu, dan Gaya Rambut' agar kelihatan sangat modis!",
    highlight: "Gunakan CSS Selector dengan tepat agar hiasan indahmu jatuh pada bagian yang benar-benar kamu inginkan!",
    example: "/* Contoh Kode CSS */\n\n/* Menghias Judul h1 */\nh1 {\n  color: blue; /* Warna tulisan biru */\n  font-size: 32px; /* Ukuran besar */\n}\n\n/* Menghias Kelas .tombol-cantik */\n.tombol-cantik {\n  background-color: yellow; /* Latar warna kuning */\n  padding: 20px; /* Isi ruang dalam tebal */\n  border-radius: 12px; /* Sudut tumpul melengkung */\n}"
  }
];


