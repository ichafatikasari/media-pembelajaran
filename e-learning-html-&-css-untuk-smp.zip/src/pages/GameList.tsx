import React from 'react';
import { motion } from 'motion/react';
import { Gamepad2, MousePointer2, Paintbrush, BoxSelect, ArrowRight, Trophy } from 'lucide-react';
import { Link } from 'react-router-dom';

const games = [
  {
    id: 'tag-pop',
    name: 'Tag Pop 🎯',
    desc: 'Tangkap tag HTML yang benar sebelum menghilang! Uji kecepatan dan pengetahuan dasarmu.',
    icon: MousePointer2,
    color: 'bg-orange-500 border-b border-white',
    path: '/game/tag-pop',
    difficulty: 'Mudah'
  },
  {
    id: 'css-painter',
    name: 'CSS Painter 🎨',
    desc: 'Bantu si pelukis memilih properti CSS yang tepat untuk mewarnai kotak target.',
    icon: Paintbrush,
    color: 'bg-brand border-b border-accent-yellow',
    path: '/game/css-painter',
    difficulty: 'Sedang'
  },
  {
    id: 'tag-builder',
    name: 'Tag Builder ⚡',
    desc: 'Susunlah potongan kode HTML dan CSS untuk membangun struktur yang diminta.',
    icon: BoxSelect,
    color: 'bg-emerald-600 border-b border-white',
    path: '/game/tag-builder',
    difficulty: 'Sulit'
  }
];

const GameList: React.FC = () => {
  return (
    <div className="space-y-8">
      <div>
        <h1 className="text-3xl font-bold text-gray-800 flex items-center gap-3">
          <Gamepad2 className="w-8 h-8 text-brand" /> Pusat Permainan
        </h1>
        <p className="text-gray-500">Pilih tantanganmu dan kumpulkan poin sebanyak-banyaknya!</p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {games.map((game) => (
          <motion.div
            key={game.id}
            whileHover={{ y: -5 }}
            className="flex flex-col bg-white rounded-3xl overflow-hidden border border-gray-100 shadow-sm hover:shadow-xl transition-all"
          >
            <div className={`h-32 ${game.color} flex items-center justify-center p-6 text-white relative`}>
               <game.icon className="w-16 h-16 opacity-40 absolute -right-4 -bottom-4 rotate-12" />
               <game.icon className="w-12 h-12 relative z-10" />
            </div>
            <div className="p-6 flex-1 flex flex-col">
              <div className="flex justify-between items-start mb-2">
                <h3 className="text-xl font-bold text-gray-800">{game.name}</h3>
                <span className="text-[10px] font-bold uppercase tracking-wider px-2 py-0.5 rounded-full bg-gray-100 text-gray-500 border border-gray-200">
                  {game.difficulty}
                </span>
              </div>
              <p className="text-gray-500 text-sm mb-6 flex-1 leading-relaxed">
                {game.desc}
              </p>
              <Link
                to={game.path}
                className="w-full bg-slate-900 hover:bg-black text-white font-bold py-3 rounded-2xl flex items-center justify-center gap-2 transition-all active:scale-95"
              >
                Mulai Bermain <ArrowRight className="w-4 h-4" />
              </Link>
            </div>
          </motion.div>
        ))}
      </div>

      <div className="bg-brand-light rounded-3xl p-8 border-2 border-dashed border-brand/20 flex flex-col md:flex-row items-center gap-8">
         <div className="text-center md:text-left space-y-2">
            <h4 className="text-xl font-bold text-brand-dark">Tahukah Kamu?</h4>
            <p className="text-brand font-medium">
              Setiap kali kamu memenangkan game, poinmu akan langsung masuk ke Leaderboard! 
              Coba tantang temanmu untuk melihat siapa yang paling jago coding.
            </p>
         </div>
         <Link to="/leaderboard" className="shrink-0 bg-brand hover:bg-brand-dark text-white font-bold px-6 py-3 rounded-2xl shadow-lg shadow-brand-light border border-accent-yellow transition-all flex items-center gap-2">
           Cek Peringkat <Trophy className="w-5 h-5 text-yellow-300" />
         </Link>
      </div>
    </div>
  );
};

export default GameList;
