import React, { useState, useEffect, useRef } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Trophy, Clock, Zap, AlertCircle, Heart, ArrowLeft, RotateCcw } from 'lucide-react';
import confetti from 'canvas-confetti';
import { useStore } from '../store/useStore';
import { useNavigate } from 'react-router-dom';

const VALID_TAGS = ['<div>', '</div>', '<h1>', '</h1>', '<p>', '</p>', '<img>', '<a>', '</a>', '<span>', '</span>', '<br>'];
const FAKE_TAGS = ['<box>', '<text>', '<color>', '<font>', '<miau>', '<link>', '<bold>', '<italic>', '<web>', '<site>'];

const FAKE_TAG_EXPLANATIONS: Record<string, string> = {
  '<box>': 'Gunakan <div>, bukan <box> mase.',
  '<text>': 'Tag <text> itu tidak ada di HTML.',
  '<color>': 'Warna itu di CSS, bukan tag.',
  '<font>': 'Tag <font> itu sudah kuno/obsolete.',
  '<miau>': 'Ini mah suara kucing, bukan tag!',
  '<link>': 'Tautan itu pakai <a>, mase.',
  '<bold>': 'Gunakan <strong>, bukan <bold>.',
  '<italic>': 'Gunakan <em>, bukan <italic>.',
  '<web>': 'Tag <web> tidak terdaftar di HTML.',
  '<site>': 'Tidak ada tag <site> di HTML5.'
};

export default function TagPop() {
  const [score, setScore] = useState(0);
  const scoreRef = useRef(0);
  
  useEffect(() => {
    scoreRef.current = score;
  }, [score]);

  const [time, setTime] = useState(30);
  const [lives, setLives] = useState(3);
  const [attempts, setAttempts] = useState(0);
  const [gameState, setGameState] = useState<'idle' | 'playing' | 'finished'>('idle');
  const [bubbles, setBubbles] = useState<{ id: number; x: number; y: number; content: string; isValid: boolean; color: string }[]>([]);
  const [feedbacks, setFeedbacks] = useState<{ id: number; x: number; y: number; text: string }[]>([]);
  const containerRef = useRef<HTMLDivElement>(null);
  
  const user = useStore((state) => state.user);
  const gameScores = useStore((state) => state.gameScores);
  const updateGameScore = useStore((state) => state.updateGameScore);
  const navigate = useNavigate();

  const isPlaying = gameState === 'playing';
  const highscore = gameScores.tagPop || 0;

  const colors = ['bg-[#10998d]', 'bg-[#0f766e]', 'bg-[#14b8a6]', 'bg-[#115e59]', 'bg-[#0d9488]'];

  const startGame = () => {
    setScore(0);
    setTime(30);
    setLives(3);
    setGameState('playing');
    setBubbles([]);
  };

  const endGame = () => {
    setGameState('finished');
    updateGameScore('tagPop', Math.max(0, scoreRef.current));

    if (scoreRef.current > 50) {
      confetti({
        particleCount: 100,
        spread: 70,
        origin: { y: 0.6 }
      });
    }
  };

  useEffect(() => {
    if (isPlaying && (lives <= 0 || time <= 0)) {
      endGame();
    }
  }, [isPlaying, lives, time]);

  useEffect(() => {
    if (!isPlaying) return;

    const timer = setInterval(() => {
      setTime(prev => prev > 0 ? prev - 1 : 0);
    }, 1000);

    const spawner = setInterval(() => {
      const isReal = Math.random() > 0.4;
      const newBubble = {
        id: Date.now() + Math.random(),
        x: 15 + Math.random() * 70,
        y: 110, // Mulai dari bawah layar
        content: isReal 
          ? VALID_TAGS[Math.floor(Math.random() * VALID_TAGS.length)]
          : FAKE_TAGS[Math.floor(Math.random() * FAKE_TAGS.length)],
        isValid: isReal,
        color: colors[Math.floor(Math.random() * colors.length)]
      };
      setBubbles(prev => [...prev, newBubble]);
    }, 1800);

    return () => {
      clearInterval(timer);
      clearInterval(spawner);
    };
  }, [isPlaying]);

  useEffect(() => {
    if (!isPlaying) return;
    const movement = setInterval(() => {
      setBubbles(prev => prev.map(b => ({ ...b, y: b.y - 0.4 })).filter(b => b.y > -20));
    }, 16);
    return () => clearInterval(movement);
  }, [isPlaying]);

  const handlePop = (id: number, isValid: boolean, x: number, y: number, content: string) => {
    if (!isPlaying) return;
    
    if (isValid) {
      setScore(prev => prev + 20);
    } else {
      setLives(prev => prev - 1);
      setScore(prev => Math.max(0, prev - 5));
      
      // Add feedback
      const feedbackId = Date.now();
      setFeedbacks(prev => [...prev, {
        id: feedbackId,
        x,
        y,
        text: FAKE_TAG_EXPLANATIONS[content] || 'Tag ini tidak valid!'
      }]);

      // Remove feedback after 2 seconds
      setTimeout(() => {
        setFeedbacks(prev => prev.filter(f => f.id !== feedbackId));
      }, 2500);
    }
    
    setBubbles(prev => prev.filter(b => b.id !== id));
  };

  return (
    <div ref={containerRef} className="relative w-full max-w-4xl mx-auto h-[480px] sm:h-[600px] bg-slate-950 rounded-[28px] sm:rounded-[40px] flex flex-col items-center justify-center overflow-hidden border-2 sm:border-4 border-brand shadow-2xl">
      <AnimatePresence mode="wait">
        {gameState === 'idle' && (
          <motion.div 
            key="idle"
            initial={{ opacity: 0, scale: 0.9 }}
            animate={{ opacity: 1, scale: 1 }}
            exit={{ opacity: 0, scale: 0.9 }}
            className="absolute inset-4 xs:inset-6 sm:inset-10 max-w-md mx-auto bg-white rounded-[24px] sm:rounded-[40px] p-5 sm:p-8 md:p-10 flex flex-col items-center justify-start sm:justify-center overflow-y-auto z-50 shadow-2xl border border-slate-100 max-h-[90%]"
          >
            <div className="w-16 h-16 sm:w-24 sm:h-24 bg-brand-light rounded-full flex items-center justify-center mx-auto mb-4 sm:mb-6 shadow-inner border border-brand/20 shrink-0">
               <Zap size={32} className="text-brand sm:w-12 sm:h-12" fill="currentColor" />
            </div>
            <h2 className="text-2xl sm:text-4xl font-black text-brand mb-2 sm:mb-4 uppercase italic tracking-tight shrink-0">Tag Pop!</h2>
            <p className="text-xs sm:text-sm text-slate-500 mb-4 sm:mb-6 font-medium italic leading-relaxed text-center shrink-0 max-w-xs">
              {highscore > 0 
                ? "Kamu sudah menyelesaikan misi ini dengan sangat baik! Ayo lanjut ke tantangan berikutnya."
                : "Hai Calon Developer! Pecahkan gelembung yang berisi Tag HTML BENAR dan hindari yang palsu!"}
            </p>
            
            {highscore === 0 ? (
              <div className="w-full shrink-0">
                <div className="bg-brand-light rounded-2xl sm:rounded-3xl p-4 sm:p-6 mb-4 sm:mb-8 border border-brand/10 text-left space-y-2.5 sm:space-y-3">
                   <div className="flex items-center gap-3 text-brand-dark font-bold text-xs sm:text-sm">
                      <div className="w-5 h-5 sm:w-6 sm:h-6 bg-brand rounded-full flex items-center justify-center text-white text-[9px] sm:text-[10px] shrink-0 font-mono">1</div>
                      <span>Gelembung Benar = +20 Poin</span>
                   </div>
                   <div className="flex items-center gap-3 text-brand-dark font-bold text-xs sm:text-sm">
                      <div className="w-5 h-5 sm:w-6 sm:h-6 bg-red-500 rounded-full flex items-center justify-center text-white text-[9px] sm:text-[10px] shrink-0 font-mono">2</div>
                      <span>Gelembung Palsu = -5 Poin & -1 Nyawa</span>
                   </div>
                   <div className="flex items-center gap-3 text-brand-dark font-bold text-xs sm:text-sm">
                      <div className="w-5 h-5 sm:w-6 sm:h-6 bg-accent-yellow rounded-full flex items-center justify-center text-slate-900 text-[9px] sm:text-[10px] shrink-0 font-mono">3</div>
                      <span>Waktumu cuma 30 detik!</span>
                   </div>
                </div>

                <button 
                  onClick={startGame}
                  className="w-full py-3.5 sm:py-5 bg-brand hover:bg-brand-dark text-white rounded-2xl font-black uppercase tracking-widest transition-all hover:scale-[1.02] active:scale-95 text-sm sm:text-lg shadow-xl shadow-brand/20 border border-accent-yellow"
                >
                  Mulai Main Sekarang
                </button>
              </div>
            ) : (
              <div className="flex flex-col gap-2.5 sm:gap-3 w-full shrink-0">
                 <button 
                   onClick={() => navigate('/game/css-painter')}
                   className="w-full py-3.5 sm:py-5 bg-accent-yellow text-slate-950 border-2 border-slate-950 rounded-2xl font-black uppercase tracking-widest shadow-xl transition-all active:scale-95 flex items-center justify-center gap-2 text-sm sm:text-lg hover:bg-yellow-500"
                 >
                   Game Berikutnya <Zap className="w-4 h-4 sm:w-5 sm:h-5 fill-current" />
                 </button>
                 <button 
                   onClick={() => navigate('/leaderboard')}
                   className="w-full py-3 sm:py-4 bg-brand-light text-brand rounded-2xl font-black uppercase tracking-widest hover:bg-brand/10 transition-all active:scale-95 flex items-center justify-center gap-2 border border-brand/10 text-xs sm:text-sm"
                 >
                   <Trophy className="w-4 h-4" /> Lihat Peringkat
                 </button>
              </div>
            )}
          </motion.div>
        )}

        {gameState === 'finished' && (
          <motion.div 
            key="finished"
            initial={{ opacity: 0, scale: 0.9 }}
            animate={{ opacity: 1, scale: 1 }}
            exit={{ opacity: 0, scale: 0.9 }}
            className="absolute inset-4 xs:inset-6 sm:inset-10 max-w-md mx-auto bg-white rounded-[24px] sm:rounded-[40px] p-5 sm:p-8 md:p-10 flex flex-col items-center justify-start sm:justify-center overflow-y-auto z-50 shadow-2xl border border-slate-100 max-h-[90%]"
          >
            <div className="w-16 h-16 sm:w-24 sm:h-24 bg-brand-light rounded-full flex items-center justify-center mx-auto mb-4 sm:mb-6 border border-brand/20 shadow-inner shrink-0">
               <Zap size={32} className="text-brand sm:w-12 sm:h-12" fill="currentColor" />
            </div>
            <h2 className="text-2xl sm:text-4xl font-black text-brand mb-1 sm:mb-2 uppercase italic tracking-tight shrink-0">Luar Biasa!</h2>
            <p className="text-xs sm:text-sm text-slate-500 mb-4 sm:mb-6 font-medium italic leading-normal text-center shrink-0">
              Kamu sudah menyelesaikan game ini! Ayo lanjut asah kemampuanmu di game berikutnya.
            </p>
            
            <div className="w-full mb-4 sm:mb-8 p-4 sm:p-6 bg-brand-light rounded-[2rem] sm:rounded-[3rem] border border-brand/10 shadow-inner text-center shrink-0">
               <p className="text-[9px] sm:text-[10px] font-black uppercase tracking-widest text-brand mb-1">Skor Akhir</p>
               <p className="text-5xl sm:text-7xl font-black text-brand-dark font-mono tracking-tighter">{score}</p>
            </div>

            <div className="flex flex-col gap-2.5 sm:gap-3 w-full shrink-0">
              <button 
                onClick={() => navigate('/leaderboard')}
                className="w-full py-3.5 sm:py-5 bg-brand hover:bg-brand-dark text-white rounded-2xl font-black uppercase tracking-widest shadow-xl shadow-brand/25 transition-all active:scale-95 flex items-center justify-center gap-2 text-sm sm:text-lg border border-accent-yellow"
              >
                <Trophy className="w-4 h-4 sm:w-5 sm:h-5" /> Lihat Peringkat
              </button>
              <div className="grid grid-cols-2 gap-2.5 sm:gap-3">
                <button 
                  onClick={() => navigate('/game/css-painter')}
                  className="py-3 sm:py-4 bg-accent-yellow hover:bg-yellow-500 text-slate-900 border border-slate-950 rounded-2xl font-black uppercase tracking-widest shadow-xl transition-all active:scale-95 flex items-center justify-center gap-1.5 text-[10px] sm:text-xs"
                >
                  Game Berikutnya <Zap className="w-3.5 h-3.5 sm:w-4 sm:h-4 fill-current text-slate-900" />
                </button>
                <button 
                  onClick={() => navigate('/game')}
                  className="py-3 sm:py-4 bg-slate-100 hover:bg-slate-200 text-slate-500 rounded-2xl font-black uppercase tracking-widest transition-all active:scale-95 flex items-center justify-center gap-1.5 text-[10px] sm:text-xs"
                >
                  Menu Utama
                </button>
              </div>
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      {(gameState === 'playing' || gameState === 'finished') && (
        <>
          {/* HUD (Hanya tampil saat main atau selesai sebagai background) */}
          <div className="absolute top-3 left-3 right-3 sm:top-6 sm:left-6 sm:right-6 flex justify-between items-center z-20 pointer-events-none">
            <div className="flex gap-2 sm:gap-3">
              <div className="bg-white/10 backdrop-blur-md px-3 py-1.5 sm:px-6 sm:py-3 rounded-xl sm:rounded-2xl border border-white/20 flex items-center gap-1.5 sm:gap-3 shadow-xl">
                <Trophy className="text-yellow-400 w-4 h-4 sm:w-5 sm:h-5 text-shadow" size={20} fill="currentColor" />
                <span className="text-base sm:text-2xl font-black text-white tabular-nums font-mono">{score}</span>
              </div>
              <div className="bg-white/10 backdrop-blur-md px-3 py-1.5 sm:px-6 sm:py-3 rounded-xl sm:rounded-2xl border border-white/20 flex items-center gap-1 sm:gap-2 shadow-xl">
                {[...Array(3)].map((_, i) => (
                  <Heart 
                    key={i} 
                    size={20} 
                    className={`${i < lives ? "text-red-500" : "text-white/20"} w-3.5 h-3.5 sm:w-5 sm:h-5`} 
                    fill={i < lives ? "currentColor" : "none"} 
                  />
                ))}
              </div>
            </div>
            <div className={`bg-white/10 backdrop-blur-md px-3 py-1.5 sm:px-6 sm:py-3 rounded-xl sm:rounded-2xl border border-white/20 flex items-center gap-1.5 sm:gap-3 shadow-xl ${time < 10 && isPlaying ? 'text-red-400 animate-pulse' : 'text-white'}`}>
              <Clock className="w-4 h-4 sm:w-5 sm:h-5" size={20} />
              <span className="text-base sm:text-2xl font-black tabular-nums font-mono">{time}s</span>
            </div>
          </div>

          {/* Game Area */}
          <div className="absolute inset-0 z-10">
            {bubbles.map(b => (
              <motion.button
                key={b.id}
                onClick={() => handlePop(b.id, b.isValid, b.x, b.y, b.content)}
                initial={{ scale: 0 }}
                animate={{ scale: 1 }}
                whileHover={{ scale: 1.1 }}
                whileTap={{ scale: 0.9 }}
                className={`absolute w-16 h-16 sm:w-24 sm:h-24 rounded-full flex items-center justify-center font-mono text-[10px] sm:text-sm font-black text-white shadow-xl ${b.color} border-[3px] sm:border-4 border-white/40 cursor-pointer pointer-events-auto`}
                style={{ 
                  left: `${b.x}%`, 
                  top: `${b.y}%`,
                  x: "-50%"
                }}
              >
                {b.content}
                <div className="absolute inset-0 rounded-full border-t-2 sm:border-t-4 border-r-2 sm:border-r-4 border-white/20 shadow-inner" />
              </motion.button>
            ))}

            {/* Error Feedbacks */}
            {feedbacks.map(f => (
              <motion.div
                key={f.id}
                initial={{ opacity: 0, scale: 0.8 }}
                animate={{ opacity: 1, scale: 1, y: -20 }}
                exit={{ opacity: 0 }}
                className="absolute z-30 pointer-events-none"
                style={{ 
                  left: `${f.x}%`, 
                  top: `${f.y}%`,
                  x: f.x < 30 ? "0%" : f.x > 70 ? "-100%" : "-50%"
                }}
              >
                <div className="bg-red-500 text-white px-2.5 py-1.5 sm:px-3 sm:py-2 rounded-xl text-[9px] sm:text-[10px] font-bold shadow-xl border-2 border-white max-w-[120px] sm:max-w-[150px] text-center leading-tight">
                  {f.text}
                </div>
              </motion.div>
            ))}
          </div>
        </>
      )}

      {/* Background Decor */}
      <div className="absolute inset-0 pointer-events-none opacity-25">
         <div className="absolute top-1/4 left-1/4 w-96 h-96 bg-brand rounded-full blur-[120px]"></div>
         <div className="absolute bottom-1/4 right-1/4 w-96 h-96 bg-brand-dark rounded-full blur-[120px]"></div>
      </div>
    </div>
  );
}

