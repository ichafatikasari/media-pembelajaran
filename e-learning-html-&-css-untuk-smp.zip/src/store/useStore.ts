import { create } from 'zustand';
import { persist, createJSONStorage } from 'zustand/middleware';
import { CLASS_PASSWORD } from '../data/users';

const TEACHER_PASSWORD = 'gurupintar';

interface User {
  username: string;
  displayName: string;
  loggedIn: boolean;
  role: 'siswa' | 'guru';
}

interface MissionProgress {
  completed: boolean;
  score: number;
  code: string;
}

interface UserData {
  displayName: string;
  missionsProgress: Record<string, MissionProgress>;
  gameScores: {
    tagPop: number;
    cssPainter: number;
    tagBuilder: number;
  };
  materiCompleted: string[];
  role?: 'siswa' | 'guru';
}

interface AppState {
  user: User | null;
  // Progres aktif user saat ini
  missionsProgress: Record<string, MissionProgress>;
  gameScores: {
    tagPop: number;
    cssPainter: number;
    tagBuilder: number;
  };
  materiCompleted: string[];
  
  // Bank data semua siswa
  usersData: Record<string, UserData>;
  
  // Actions
  login: (displayName: string, psw: string) => boolean;
  logout: () => void;
  completeMission: (id: string, score: number, code: string) => void;
  updateGameScore: (gameKey: 'tagPop' | 'cssPainter' | 'tagBuilder', score: number) => void;
  completeMateri: (topicId: string) => void;
  resetGameScores: () => void;
  getTotalPoints: () => number;
  getGameTotal: () => number;
  getMissionTotal: () => number;
  getLeaderboard: () => { name: string, gameScore: number, missionScore: number, total: number }[];
  resetAllData: () => void;
}

export const useStore = create<AppState>()(
  persist(
    (set, get) => ({
      user: null,
      missionsProgress: {},
      gameScores: {
        tagPop: 0,
        cssPainter: 0,
        tagBuilder: 0,
      },
      materiCompleted: [],
      usersData: {},

      login: (displayName, psw) => {
        const name = displayName.trim();
        if (name.length === 0) return false;

        const isTeacher = psw === TEACHER_PASSWORD;
        const isStudent = psw === CLASS_PASSWORD;

        if (isTeacher || isStudent) {
          const username = name.toLowerCase().replace(/\s+/g, '_');
          const role = isTeacher ? 'guru' : 'siswa';
          
          const existingData = get().usersData[username];

          // Jika akun ini sudah terdaftar sebagai guru atau merupakan nama sensitif guru/admin (seperti guru, admin, dll),
          // dilarang login menggunakan password/akses siswa biasa agar role-nya tidak tertimpa/muncul di leaderboard.
          const isTeacherName = 
            username === 'guru' || 
            username === 'admin' || 
            username === 'teacher';

          if ((existingData?.role === 'guru' || isTeacherName) && role === 'siswa') {
            return false;
          }

          const userData = existingData || {
            displayName: name,
            missionsProgress: {},
            gameScores: { tagPop: 0, cssPainter: 0, tagBuilder: 0 },
            materiCompleted: [],
            role
          };

          set((s) => ({ 
            user: { username, displayName: name, loggedIn: true, role },
            missionsProgress: userData.missionsProgress,
            gameScores: userData.gameScores,
            materiCompleted: userData.materiCompleted,
            usersData: {
              ...s.usersData,
              [username]: {
                ...userData,
                displayName: name, // Ensure displayName is saved
                role // Simpan atau update role-nya
              }
            }
          }));
          return true;
        }
        return false;
      },

      logout: () => {
        const state = get();
        if (state.user) {
          const username = state.user.username;
          set((s) => ({
            usersData: {
              ...s.usersData,
              [username]: {
                ...s.usersData[username],
                missionsProgress: s.missionsProgress,
                gameScores: s.gameScores,
                materiCompleted: s.materiCompleted,
                role: state.user?.role || s.usersData[username]?.role // Pastikan role selalu tersimpan saat keluar
              }
            },
            user: null,
            missionsProgress: {},
            gameScores: { tagPop: 0, cssPainter: 0, tagBuilder: 0 },
            materiCompleted: []
          }));
        }
      },

      completeMission: (id, score, code) => {
        set((state) => {
          const currentProgress = state.missionsProgress[id];
          const bestScore = currentProgress ? Math.max(currentProgress.score, score) : score;
          const newProgress = {
            ...state.missionsProgress,
            [id]: { completed: true, score: bestScore, code }
          };
          
          // Sinkronkan ke usersData secara real-time agar tidak hilang jika lupa logout
          const username = state.user?.username || '';
          return {
            missionsProgress: newProgress,
            usersData: username ? {
              ...state.usersData,
              [username]: {
                ...state.usersData[username],
                missionsProgress: newProgress
              }
            } : state.usersData
          };
        });
      },

      updateGameScore: (gameKey, score) => {
        set((state) => {
          const currentScore = state.gameScores[gameKey] || 0;
          const bestScore = Math.max(currentScore, score);
          const newScores = {
            ...state.gameScores,
            [gameKey]: bestScore
          };

          const username = state.user?.username || '';
          return {
            gameScores: newScores,
            usersData: username ? {
              ...state.usersData,
              [username]: {
                ...state.usersData[username],
                gameScores: newScores
              }
            } : state.usersData
          };
        });
      },

      completeMateri: (topicId) => {
        set((state) => {
          const newMateri = state.materiCompleted.includes(topicId)
            ? state.materiCompleted
            : [...state.materiCompleted, topicId];

          const username = state.user?.username || '';
          return {
            materiCompleted: newMateri,
            usersData: username ? {
              ...state.usersData,
              [username]: {
                ...state.usersData[username],
                materiCompleted: newMateri
              }
            } : state.usersData
          };
        });
      },

      resetGameScores: () => {
        // Hanya reset untuk user yang sedang aktif
        set({
          gameScores: { tagPop: 0, cssPainter: 0, tagBuilder: 0 }
        });
      },

      getTotalPoints: () => {
        return get().getGameTotal() + get().getMissionTotal();
      },

      getGameTotal: () => {
        const { tagPop, cssPainter, tagBuilder } = get().gameScores;
        return tagPop + cssPainter + tagBuilder;
      },

      getMissionTotal: () => {
        return Object.values(get().missionsProgress).reduce((acc, curr) => acc + curr.score, 0);
      },

      getLeaderboard: () => {
        const allUsers = get().usersData;
        return Object.entries(allUsers)
          .filter(([username, data]) => {
            // 1. Saring jika rolenya secara eksplisit 'guru'
            if (data.role === 'guru') return false;

            // 2. Saring jika username atau display name mengandung kata sensitif guru (case-insensitive)
            // Ini untuk menangani legacy data dari session lama atau akun uji coba guru
            const usernameLower = username.toLowerCase();
            const displayNameLower = (data.displayName || '').toLowerCase();
            if (
              usernameLower.includes('guru') ||
              displayNameLower.includes('guru') ||
              usernameLower.includes('admin') ||
              displayNameLower.includes('admin') ||
              usernameLower.includes('teacher') ||
              displayNameLower.includes('teacher')
            ) {
              return false;
            }

            return true;
          })
          .map(([username, data]) => {
            const gameTotal = (data.gameScores?.tagPop || 0) + (data.gameScores?.cssPainter || 0) + (data.gameScores?.tagBuilder || 0);
            const missionTotal = Object.values(data.missionsProgress || {}).reduce((acc, curr) => acc + curr.score, 0);
            
            return {
              name: data.displayName || username.replace(/_/g, ' ').toUpperCase(),
              gameScore: gameTotal,
              missionScore: missionTotal,
              total: gameTotal + missionTotal
            };
          }).sort((a, b) => b.total - a.total);
      },

      resetAllData: () => {
        set({ usersData: {} });
      }
    }),
    {
      name: 'elearning-html-css-storage',
      storage: createJSONStorage(() => localStorage),
    }
  )
);
