import React from 'react';
import { motion } from 'motion/react';
import { Play, Clock, ExternalLink } from 'lucide-react';

const videos = [
  {
    id: "1",
    title: "Belajar HTML Dasar untuk Pemula",
    url: "https://www.youtube.com/embed/JnedlCxqCL4",
    duration: "15:00",
    thumbnail: "https://img.youtube.com/vi/JnedlCxqCL4/mqdefault.jpg"
  },
  {
    id: "2",
    title: "Tutorial CSS untuk Pemula",
    url: "https://www.youtube.com/embed/wriGST3vp5M",
    duration: "12:00",
    thumbnail: "https://img.youtube.com/vi/wriGST3vp5M/mqdefault.jpg"
  },
  {
    id: "3",
    title: "Latihan Membuat Website Sederhana",
    url: "https://www.youtube.com/embed/AQOBN9XByf0",
    duration: "20:00",
    thumbnail: "https://img.youtube.com/vi/AQOBN9XByf0/mqdefault.jpg"
  }
];

const Video: React.FC = () => {
  const [selectedVideo, setSelectedVideo] = React.useState(videos[0]);

  return (
    <div className="space-y-8">
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
        <div>
          <h1 className="text-3xl font-bold text-gray-800">Video Pembelajaran</h1>
          <p className="text-gray-500">Tonton tutorial coding agar makin mahir!</p>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        {/* Active Player */}
        <div className="lg:col-span-2 space-y-4">
          <div className="relative aspect-video bg-black rounded-3xl overflow-hidden shadow-2xl">
            <iframe
              src={selectedVideo.url}
              title={selectedVideo.title}
              className="absolute inset-0 w-full h-full border-0"
              allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
              allowFullScreen
            />
          </div>
          <div className="bg-white p-6 rounded-3xl border border-gray-100 shadow-sm flex justify-between items-center">
            <div>
              <h2 className="text-2xl font-bold text-gray-800 ">{selectedVideo.title}</h2>
              <div className="flex items-center gap-4 mt-2 text-gray-500 text-sm">
                <span className="flex items-center gap-1"><Clock className="w-4 h-4" /> Durasi: {selectedVideo.duration}</span>
                <span className="flex items-center gap-1 text-brand font-medium">
                  <Play className="w-4 h-4" /> Sedang Diputar
                </span>
              </div>
            </div>
          </div>
        </div>

        {/* Playlist */}
        <div className="space-y-4">
          <h3 className="text-xl font-bold text-gray-800 px-2">Video Lainnya</h3>
          <div className="space-y-3 max-h-[600px] overflow-y-auto pr-2 custom-scrollbar">
            {videos.map((vid) => (
              <motion.button
                whileHover={{ x: 5 }}
                key={vid.id}
                onClick={() => setSelectedVideo(vid)}
                className={`w-full flex gap-3 p-3 rounded-2xl border transition-all text-left ${
                  selectedVideo.id === vid.id 
                    ? 'bg-brand-light border-brand/20 shadow-sm' 
                    : 'bg-white border-gray-100 hover:border-brand/30 hover:bg-gray-50'
                }`}
              >
                <div className="relative w-28 h-16 rounded-lg overflow-hidden shrink-0">
                  <img src={vid.thumbnail} alt={vid.title} className="w-full h-full object-cover" />
                  <div className="absolute inset-0 bg-black/20 flex items-center justify-center">
                    <Play className="w-5 h-5 text-white fill-current" />
                  </div>
                </div>
                <div className="flex flex-col justify-between py-1 overflow-hidden">
                  <p className={`text-sm font-bold truncate ${selectedVideo.id === vid.id ? 'text-brand font-black' : 'text-gray-800'}`}>
                    {vid.title}
                  </p>
                  <span className="text-xs text-gray-400">{vid.duration} menit</span>
                </div>
              </motion.button>
            ))}
          </div>
          
          <div className="p-6 bg-brand rounded-3xl text-white shadow-lg overflow-hidden relative border-2 border-accent-yellow">
             <div className="relative z-10">
               <p className="text-xs font-bold uppercase text-brand-light mb-1">Misi Belajar</p>
               <h4 className="text-lg font-bold mb-3">Tonton & Praktikkan</h4>
               <p className="text-sm opacity-90 mb-4 leading-relaxed">Setelah nonton, coba dipraktikkan langsung di menu Misi ya!</p>
               <button className="bg-white/20 hover:bg-white/30 backdrop-blur-md px-4 py-2 rounded-xl text-sm font-bold transition-all flex items-center gap-2">
                 Buka Menu Misi <ExternalLink className="w-4 h-4" />
               </button>
             </div>
             <div className="absolute -right-4 -bottom-4 w-20 h-20 bg-white/10 rounded-full blur-xl"></div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Video;
