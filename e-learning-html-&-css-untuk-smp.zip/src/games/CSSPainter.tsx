import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Heart, Trophy, RotateCcw, Home, CheckCircle2, XCircle, Palette, Zap } from 'lucide-react';
import { cssPainterData } from '../data/gameData';
import { useNavigate } from 'react-router-dom';
import { cn } from '../lib/utils';
import { useStore } from '../store/useStore';
import confetti from 'canvas-confetti';

const CSSPainter: React.FC = () => {
  const [currentLevel, setCurrentLevel] = useState(0);
  const [isPlaying, setIsPlaying] = useState(false);
  const [score, setScore] = useState(0);
  const [lives, setLives] = useState(3);
  const [gameOver, setGameOver] = useState(false);
  const [selectedStyles, setSelectedStyles] = useState<Record<string, string>>({});
  const [isCorrect, setIsCorrect] = useState<boolean | null>(null);

  const updateGameScore = useStore((state) => state.updateGameScore);
  const gameScores = useStore((state) => state.gameScores);
  const navigate = useNavigate();

  const level = cssPainterData[currentLevel];
  const highscore = gameScores.cssPainter || 0;

  const startGame = () => {
    setIsPlaying(true);
    setScore(0);
    setLives(3);
    setGameOver(false);
    setCurrentLevel(0);
    setSelectedStyles({});
    setIsCorrect(null);
  };

  const handleOptionClick = (value: string) => {
    if (isCorrect !== null) return;
    
    const styleProperty = level.property.replace(/-([a-z])/g, (g) => g[1].toUpperCase());
    const isAnswerCorrect = value === level.targetValue;
    const nextScore = isAnswerCorrect ? score + 20 : Math.max(0, score - 10);
    
    setSelectedStyles({ ...selectedStyles, [styleProperty]: value });
    setIsCorrect(isAnswerCorrect);
    setScore(nextScore);

    if (isAnswerCorrect) {
      confetti({
        particleCount: 50,
        spread: 40,
        origin: { y: 0.7 }
      });
    } else {
      setLives(prev => prev - 1);
    }

    setTimeout(() => {
      const nextLives = isAnswerCorrect ? lives : lives - 1;
      
      if (nextLives <= 0) {
        finishGame(nextScore);
      } else if (currentLevel < cssPainterData.length - 1) {
        setCurrentLevel(prev => prev + 1);
        setSelectedStyles({}); // Reset styles for next level to make it feel fresh
        setIsCorrect(null);
      } else {
        finishGame(nextScore);
      }
    }, 2000); // Give time to see feedback
  };

  const finishGame = (finalScore: number) => {
    setIsPlaying(false);
    setGameOver(true);
    updateGameScore('cssPainter', Math.max(0, finalScore));
  };

  return (
    <div className="max-w-4xl mx-auto space-y-6">
      {/* HUD */}
      {(isPlaying || gameOver) && (
        <div className="bg-white rounded-3xl p-4 border border-gray-100 shadow-sm flex items-center justify-between">
          <div className="flex items-center gap-6">
            <div className="flex flex-col">
              <span className="text-[10px] font-bold text-gray-400 uppercase tracking-widest">Skor Level Ini</span>
              <span className="text-2xl font-black text-brand font-mono">{score}</span>
            </div>
            <div className="w-px h-8 bg-gray-100"></div>
            <div className="flex flex-col">
              <span className="text-[10px] font-bold text-gray-400 uppercase tracking-widest">Soal</span>
              <span className="text-2xl font-black text-slate-800 font-mono">{currentLevel + 1}/{cssPainterData.length}</span>
            </div>
          </div>

          <div className="flex gap-2">
            {[...Array(3)].map((_, i) => (
              <Heart 
                key={i} 
                className={cn(
                  "w-8 h-8 transition-all",
                  i < lives ? "text-red-500 fill-current" : "text-gray-200"
                )}
              />
            ))}
          </div>
        </div>
      )}

      {/* Main Container */}
      <div className="bg-white rounded-[2.5rem] border border-gray-100 shadow-sm overflow-hidden flex flex-col md:flex-row min-h-[500px] h-auto md:h-[500px] relative">
        {!isPlaying && !gameOver ? (
          <div className="flex-1 flex flex-col items-center justify-center p-12 text-center bg-white w-full">
            <div className="w-24 h-24 bg-brand-light rounded-full flex items-center justify-center mb-6 border border-brand/20">
               <Palette className="w-12 h-12 text-brand" />
            </div>
            <h2 className="text-4xl font-black text-slate-800 mb-4 italic uppercase">CSS Painter</h2>
            <p className="text-slate-500 mb-10 max-w-sm leading-relaxed font-semibold italic">
              {highscore > 0 
                ? "Kamu sudah menyelesaikan game ini dengan sangat baik! Ayo asah kreativitas senimu." 
                : "Bantu si pelukis memilih kode CSS yang tepat untuk merubah tampilan kotak di layar!"}
            </p>
            {highscore === 0 ? (
              <button 
                onClick={startGame}
                className="px-10 py-5 bg-brand hover:bg-brand-dark text-white font-black rounded-2xl shadow-xl shadow-brand-light transition-all uppercase tracking-widest active:scale-95 border border-accent-yellow"
              >
                Mulai Melukis
              </button>
            ) : (
              <div className="flex flex-col gap-3 w-full max-w-xs shrink-0">
                <button 
                  onClick={() => navigate('/game/tag-builder')}
                  className="w-full py-4 sm:py-5 bg-accent-yellow hover:bg-yellow-500 text-slate-900 font-black rounded-2xl shadow-xl transition-all uppercase tracking-widest active:scale-95 border-2 border-slate-900 flex items-center justify-center gap-2 text-sm"
                >
                  Game Berikutnya <Zap className="w-4 h-4 fill-current text-slate-900" />
                </button>
                <button 
                  onClick={() => navigate('/leaderboard')}
                  className="w-full py-3 sm:py-4 bg-brand-light text-brand rounded-2xl font-black uppercase tracking-widest hover:bg-brand/10 transition-all active:scale-95 flex items-center justify-center gap-2 border border-brand/10 text-xs sm:text-sm"
                >
                  <Trophy className="w-4 h-4" /> Lihat Peringkat
                </button>
              </div>
            )}
          </div>
        ) : (
          <>
            {/* Left: Preview Area */}
            <div className="flex-1 bg-slate-100 p-8 flex items-center justify-center relative min-h-[300px]">
               <div className="absolute top-0 left-0 p-4 font-black text-slate-400 uppercase tracking-widest text-[10px]">
                  Layar Preview
               </div>
               
               <motion.div 
                 key={currentLevel}
                 initial={{ scale: 0.8, opacity: 0 }}
                 animate={{ 
                   scale: isCorrect === true ? [1, 1.1, 1] : isCorrect === false ? [1, 0.9, 1] : 1,
                   x: isCorrect === false ? [0, -10, 10, -10, 10, 0] : 0,
                   opacity: 1,
                   ...selectedStyles
                 }}
                 transition={{
                   opacity: { duration: 0.3 }
                 }}
                 className={cn(
                   "w-48 h-48 bg-white shadow-2xl border-4 border-slate-100 overflow-hidden transition-all duration-500",
                   currentLevel !== 4 && "flex items-center justify-center text-center px-6"
                 )}
                 style={{
                   backgroundColor: selectedStyles.backgroundColor || "#ffffff",
                   borderRadius: selectedStyles.borderRadius || "0px",
                   padding: selectedStyles.padding || "0px",
                   color: selectedStyles.color || "#0f172a",
                   fontSize: selectedStyles.fontSize || "14px",
                 }}
               >
                  <span className={cn(
                    "font-black italic leading-tight uppercase tracking-tighter transition-all duration-300",
                    currentLevel === 4 && "block"
                  )}>
                     {currentLevel === 0 && "Ubah Warnaku!"}
                     {currentLevel === 1 && "Warnai Latarku!"}
                     {currentLevel === 2 && "Perbesar Aku!"}
                     {currentLevel === 3 && "Bulatkan Sudutku!"}
                     {currentLevel === 4 && "Berikan Ruang!"}
                  </span>
               </motion.div>

               <AnimatePresence>
                 {isCorrect !== null && (
                   <motion.div
                     initial={{ opacity: 0, y: 30 }}
                     animate={{ opacity: 1, y: 0 }}
                     exit={{ opacity: 0, scale: 0.5 }}
                     className={cn(
                       "absolute bottom-8 px-6 py-4 rounded-2xl font-black uppercase tracking-widest flex flex-col items-center gap-1 shadow-xl text-center min-w-[240px]",
                       isCorrect ? "bg-emerald-500 text-white" : "bg-red-500 text-white"
                     )}
                   >
                     <div className="flex items-center gap-2">
                        {isCorrect ? (
                          <><CheckCircle2 /> Benar! +20</>
                        ) : (
                          <><XCircle /> Salah! -10</>
                        )}
                     </div>
                     {!isCorrect && (
                       <div className="text-[10px] opacity-90 lowercase font-mono">
                          seharusnya: {level?.property}: <span className="font-bold">{level?.targetValue}</span>;
                       </div>
                     )}
                   </motion.div>
                 )}
               </AnimatePresence>
            </div>

            {/* Right: Controls Area */}
            <div className="w-full md:w-[400px] p-8 space-y-6 overflow-y-auto border-l border-gray-100 flex flex-col justify-center">
               <div>
                  <h4 className="text-[10px] font-black text-brand uppercase tracking-[0.2em] mb-2">Level {currentLevel + 1} dari {cssPainterData.length}</h4>
                  <p className="text-xl font-bold text-gray-800 leading-tight">
                    {level?.question}
                  </p>
               </div>

               <div className="p-4 bg-brand-light rounded-2xl font-mono text-sm border border-brand/10 text-slate-700">
                  <span className="text-brand font-black">.kotak</span> {'{'}
                  <div className="pl-4">
                    <span className="text-purple-500">{level?.property}</span>: 
                    <span className="text-brand font-black ml-2 animate-pulse">
                       {selectedStyles[level?.property.replace(/-([a-z])/g, (g) => g[1].toUpperCase())] || '______'}
                    </span>;
                  </div>
                  {'}'}
               </div>

               <div className="grid grid-cols-1 gap-3 pt-4">
                  {level?.options.map((option) => (
                    <button
                      key={option}
                      onClick={() => handleOptionClick(option)}
                      className={cn(
                        "p-4 rounded-xl font-bold transition-all border-2 text-left px-6",
                        selectedStyles[level?.property.replace(/-([a-z])/g, (g) => g[1].toUpperCase())] === option
                          ? "bg-brand border-brand text-white shadow-md shadow-brand/10"
                          : "bg-white border-gray-100 text-gray-600 hover:border-brand hover:text-brand font-semibold"
                      )}
                    >
                      {option}
                    </button>
                  ))}
               </div>
            </div>

            {/* Completion Popup Overlay (Styled like Tag Pop) */}
            <AnimatePresence>
              {gameOver && (
                <motion.div
                  key="finished-popup"
                  initial={{ opacity: 0 }}
                  animate={{ opacity: 1 }}
                  exit={{ opacity: 0 }}
                  className="absolute inset-0 bg-slate-950/70 backdrop-blur-sm z-50 flex items-center justify-center p-4"
                >
                  <motion.div
                    initial={{ opacity: 0, scale: 0.9 }}
                    animate={{ opacity: 1, scale: 1 }}
                    exit={{ opacity: 0, scale: 0.9 }}
                    className="w-full max-w-md bg-white rounded-[24px] sm:rounded-[40px] p-5 sm:p-8 flex flex-col items-center justify-center text-center shadow-2xl border border-slate-100 max-h-[95%] overflow-y-auto"
                  >
                    <div className="w-16 h-16 sm:w-24 sm:h-24 bg-brand-light rounded-full flex items-center justify-center mx-auto mb-4 sm:mb-6 border border-brand/20 shadow-inner shrink-0 animate-bounce">
                       <Zap size={32} className="text-brand sm:w-12 sm:h-12" fill="currentColor" />
                    </div>
                    <h2 className="text-2xl sm:text-4xl font-black text-brand mb-1 sm:mb-2 uppercase italic tracking-tight shrink-0">Luar Biasa!</h2>
                    <p className="text-xs sm:text-sm text-slate-500 mb-4 sm:mb-6 font-medium italic leading-normal text-center shrink-0">
                       Bakat senimu dalam CSS luar biasa! Ayo lanjut asah kemampuanmu di game berikutnya.
                    </p>
                    
                    <div className="w-full mb-4 sm:mb-8 p-4 sm:p-6 bg-brand-light rounded-[2rem] sm:rounded-[3rem] border border-brand/10 shadow-inner text-center shrink-0">
                       <p className="text-[9px] sm:text-[10px] font-black uppercase tracking-widest text-brand mb-1">Skor Akhir</p>
                       <p className="text-5xl sm:text-7xl font-black text-brand-dark font-mono tracking-tighter">{score}</p>
                    </div>

                    <div className="flex flex-col gap-2.5 sm:gap-3 w-full shrink-0">
                      <button 
                        onClick={() => navigate('/leaderboard')}
                        className="w-full py-3.5 sm:py-5 bg-brand hover:bg-brand-dark text-white rounded-2xl font-black uppercase tracking-widest shadow-xl shadow-brand/25 transition-all active:scale-95 flex items-center justify-center gap-2 text-sm sm:text-base border border-accent-yellow"
                      >
                        <Trophy className="w-4 h-4 sm:w-5 sm:h-5" /> Lihat Peringkat
                      </button>
                      <div className="grid grid-cols-2 gap-2.5 sm:gap-3">
                        <button 
                          onClick={() => navigate('/game/tag-builder')}
                          className="py-3 sm:py-4 bg-accent-yellow hover:bg-yellow-500 text-slate-900 border border-slate-150 rounded-2xl font-black uppercase tracking-widest shadow-xl transition-all active:scale-95 flex items-center justify-center gap-1.5 text-[10px] sm:text-xs"
                        >
                          Game Berikutnya <Zap className="w-3.5 h-3.5 sm:w-4 sm:h-4 fill-current text-slate-900" />
                        </button>
                        <button 
                          onClick={() => navigate('/game')}
                          className="py-3 sm:py-4 bg-slate-100 hover:bg-slate-200 text-slate-500 rounded-2xl font-black uppercase tracking-widest transition-all active:scale-95 flex items-center justify-center gap-1.5 text-[10px] sm:text-xs"
                        >
                          Menu Utama
                        </button>
                      </div>
                    </div>
                  </motion.div>
                </motion.div>
              )}
            </AnimatePresence>
          </>
        )}
      </div>

      <div className="bg-brand-light rounded-2xl p-4 flex items-center gap-3 border border-brand/10">
         <div className="bg-white p-2 rounded-lg text-brand shadow-sm">
            <Zap size={20} fill="currentColor" className="text-accent-yellow" />
         </div>
         <p className="text-xs text-brand-dark font-medium">
            <strong>Tips Belajar:</strong> Pilihlah opsi atribut yang sesuai gaya CSS agar kotak preview di sebelah kiri berubah secara langsung!
         </p>
      </div>
    </div>
  );
};

export default CSSPainter;
