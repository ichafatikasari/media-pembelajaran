import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { useStore } from '../store/useStore';
import { Heart, Trophy, RotateCcw, Home, CheckCircle2, XCircle, Code2, Trash2, Zap } from 'lucide-react';
import { tagBuilderData } from '../data/gameData';
import { useNavigate } from 'react-router-dom';
import { cn } from '../lib/utils';
import confetti from 'canvas-confetti';

const shuffleArray = (array: string[], correctSeq: string[]) => {
  let arr = [...array];
  if (arr.length <= 1) return arr;
  
  let attempts = 0;
  // Shuffle and guarantee that the order is NOT the correct sequence
  do {
    for (let i = arr.length - 1; i > 0; i--) {
      const j = Math.floor(Math.random() * (i + 1));
      [arr[i], arr[j]] = [arr[j], arr[i]];
    }
    attempts++;
  } while (JSON.stringify(arr) === JSON.stringify(correctSeq) && attempts < 10);
  
  return arr;
};

const TagBuilder: React.FC = () => {
  const [isPlaying, setIsPlaying] = useState(false);
  const [currentLevel, setCurrentLevel] = useState(0);
  const [score, setScore] = useState(0);
  const [lives, setLives] = useState(3);
  const [gameOver, setGameOver] = useState(false);
  const [selectedBlocks, setSelectedBlocks] = useState<string[]>([]);
  const [isCorrect, setIsCorrect] = useState<boolean | null>(null);
  const [shuffledElements, setShuffledElements] = useState<string[]>([]);

  const updateGameScore = useStore((state) => state.updateGameScore);
  const gameScores = useStore((state) => state.gameScores);
  const navigate = useNavigate();

  const level = tagBuilderData[currentLevel];
  const highscore = gameScores.tagBuilder || 0;

  useEffect(() => {
    if (level) {
      setShuffledElements(shuffleArray(level.elements, level.correctSequence));
    }
  }, [currentLevel, isPlaying]);

  const startGame = () => {
    setIsPlaying(true);
    setCurrentLevel(0);
    setScore(0);
    setLives(3);
    setGameOver(false);
    setSelectedBlocks([]);
  };

  const addBlock = (block: string) => {
    if (isCorrect !== null) return;
    setSelectedBlocks((prev) => [...prev, block]);
  };

  const removeBlock = (index: number) => {
    if (isCorrect !== null) return;
    setSelectedBlocks((prev) => prev.filter((_, i) => i !== index));
  };

  const checkAnswer = () => {
    const correct = JSON.stringify(selectedBlocks) === JSON.stringify(level.correctSequence);
    
    if (correct) {
      const newScore = score + 20;
      setIsCorrect(true);
      setScore(newScore);
      
      confetti({
        particleCount: 60,
        spread: 50,
        origin: { y: 0.7 }
      });

      setTimeout(() => {
        setIsCorrect(null);
        if (currentLevel < tagBuilderData.length - 1) {
          setCurrentLevel((prev) => prev + 1);
          setSelectedBlocks([]);
        } else {
          finishGame(newScore);
        }
      }, 1500);
    } else {
      const nextScore = Math.max(0, score - 10);
      setIsCorrect(false);
      setScore(nextScore);
      setLives((prev) => {
        const nextLives = prev - 1;
        if (nextLives <= 0) {
          setTimeout(() => {
            setIsCorrect(null);
            finishGame(nextScore);
          }, 1000);
        } else {
          setTimeout(() => {
            setIsCorrect(null);
            setSelectedBlocks([]); 
          }, 1000);
        }
        return nextLives;
      });
    }
  };

  const finishGame = (finalScore: number) => {
    setIsPlaying(false);
    setGameOver(true);
    updateGameScore('tagBuilder', Math.max(0, finalScore));
  };

  return (
    <div className="max-w-4xl mx-auto space-y-6">
      {/* HUD */}
      {(isPlaying || gameOver) && (
        <div className="bg-white rounded-3xl p-4 border border-gray-100 shadow-sm flex items-center justify-between">
          <div className="flex items-center gap-6">
            <div className="flex flex-col">
              <span className="text-[10px] font-bold text-gray-400 uppercase tracking-widest">Skor Level Ini</span>
              <span className="text-2xl font-black text-brand font-mono">{score}</span>
            </div>
            <div className="w-px h-8 bg-gray-100"></div>
            <div className="flex flex-col">
              <span className="text-[10px] font-bold text-gray-400 uppercase tracking-widest">Misi</span>
              <span className="text-2xl font-black text-slate-800 font-mono">{currentLevel + 1}/{tagBuilderData.length}</span>
            </div>
          </div>

          <div className="flex gap-2">
            {[...Array(3)].map((_, i) => (
              <Heart 
                key={i} 
                className={cn(
                  "w-8 h-8 transition-all",
                  i < lives ? "text-red-500 fill-current" : "text-gray-200"
                )}
              />
            ))}
          </div>
        </div>
      )}

      <div className="bg-white rounded-[2.5rem] border border-gray-100 shadow-sm min-h-[500px] flex flex-col relative overflow-hidden">
        {!isPlaying && !gameOver ? (
          <div className="flex-1 flex flex-col items-center justify-center p-12 text-center bg-white">
            <div className="w-24 h-24 bg-brand-light rounded-full flex items-center justify-center mb-6 border border-brand/20 shadow-inner">
               <Code2 className="w-12 h-12 text-brand" />
            </div>
            <h2 className="text-4xl font-black text-brand mb-4 italic uppercase">Tag Builder</h2>
            <p className="text-slate-500 mb-10 max-w-sm leading-relaxed font-semibold italic">
              {highscore > 0 
                ? "Hebat! Semua level sudah kamu selesaikan. Ayo cek peringkatmu di leaderboard!" 
                : "Susunlah potongan kode HTML sesuai urutan yang benar untuk menyelesaikan tantangan!"}
            </p>
            {highscore === 0 ? (
              <button 
                onClick={startGame}
                className="px-10 py-5 bg-brand hover:bg-brand-dark text-white font-black rounded-2xl shadow-xl shadow-brand-light transition-all uppercase tracking-widest active:scale-95 border border-accent-yellow"
              >
                Mulai Menyusun
              </button>
            ) : (
              <button 
                onClick={() => navigate('/leaderboard')}
                className="px-10 py-5 bg-accent-yellow hover:bg-yellow-500 text-slate-900 font-black rounded-2xl shadow-xl transition-all uppercase tracking-widest active:scale-95 flex items-center justify-center gap-2 border-2 border-slate-900"
              >
                Lihat Peringkat <Trophy size={20} className="text-slate-900" />
              </button>
            )}
          </div>
        ) : gameOver ? (
          <div className="flex-1 flex flex-col items-center justify-center p-12 text-center bg-white">
            <div className="w-24 h-24 bg-yellow-105 rounded-full flex items-center justify-center mb-6 border-2 border-accent-yellow">
               <Trophy className="w-12 h-12 text-yellow-600" />
            </div>
            <h2 className="text-4xl font-black text-brand mb-2 uppercase italic tracking-tight">Permainan Selesai!</h2>
            <p className="text-slate-400 mb-8 font-medium">Kamu adalah Mastah HTML & CSS!</p>
            
            <div className="bg-brand-light rounded-[2.5rem] px-10 py-8 mb-10 border border-brand/10 w-full max-w-xs text-center">
               <p className="text-[10px] font-black uppercase tracking-widest text-brand mb-1">Skor Akhir</p>
               <p className="text-6xl font-black text-brand-dark">{score}</p>
            </div>

            <div className="flex flex-col gap-3 w-full max-w-sm font-semibold">
               <button 
                 onClick={() => navigate('/leaderboard')}
                 className="w-full py-4 bg-brand hover:bg-brand-dark text-white rounded-2xl font-black uppercase tracking-widest shadow-xl shadow-brand/20 transition-all active:scale-95 flex items-center justify-center gap-2 border border-accent-yellow"
               >
                 <Trophy className="w-5 h-5" /> Lihat Peringkat
               </button>
               <button 
                 onClick={() => navigate('/game')}
                 className="w-full py-4 bg-slate-100 hover:bg-slate-200 text-slate-500 rounded-2xl font-black uppercase tracking-widest transition-all active:scale-95 flex items-center justify-center gap-2"
               >
                 Menu Utama
               </button>
            </div>
          </div>
        ) : (
          <div className="p-8 flex-1 flex flex-col gap-8">
            {/* Mission Goal */}
            <div className="bg-brand-light p-6 rounded-3xl border border-brand/10 flex items-start gap-4">
               <div className="bg-brand text-white p-2 rounded-xl shrink-0 shadow-md">
                  <Zap size={20} fill="currentColor" className="text-accent-yellow" />
               </div>
               <div>
                  <h4 className="text-[10px] font-black text-brand uppercase tracking-widest mb-1">Tugas Kamu:</h4>
                  <p className="text-xl font-bold text-brand-dark leading-tight">{level.goal}</p>
               </div>
            </div>

            {/* Build Area */}
            <div className="flex-1 flex flex-col gap-4">
               <div className="flex justify-between items-end px-2">
                 <p className="text-[10px] font-black text-slate-400 uppercase tracking-widest">Meja Rakitan</p>
                 {selectedBlocks.length > 0 && (
                   <button onClick={() => setSelectedBlocks([])} className="text-[10px] font-bold text-red-500 uppercase hover:underline">Hapus Semua</button>
                 )}
               </div>
               <div className="flex-1 bg-slate-50 rounded-[2.5rem] border-2 border-dashed border-slate-200 p-6 flex flex-wrap content-center justify-center gap-3 shadow-inner">
                  {selectedBlocks.length === 0 && (
                    <p className="text-slate-300 font-medium italic">Klik blok di bawah untuk menyusun kode...</p>
                  )}
                  <AnimatePresence>
                    {selectedBlocks.map((block, i) => (
                      <motion.button
                        layout
                        initial={{ opacity: 0, scale: 0.8 }}
                        animate={{ opacity: 1, scale: 1 }}
                        exit={{ opacity: 0, scale: 0.8 }}
                        key={`${block}-${i}`}
                        onClick={() => removeBlock(i)}
                        className="bg-brand text-white px-5 py-3 rounded-2xl font-mono text-sm font-bold border-b-4 border-brand-dark flex items-center gap-2 group shadow-lg"
                      >
                        {block}
                        <Trash2 className="w-3 h-3 opacity-50 group-hover:opacity-100" />
                      </motion.button>
                    ))}
                  </AnimatePresence>
               </div>
            </div>

            {/* Selection Area */}
            <div className="space-y-4">
               <p className="text-[10px] font-black text-slate-400 uppercase tracking-widest px-2">Pilihan Blok Kode</p>
               <div className="flex flex-wrap justify-center gap-3">
                  {shuffledElements.map((block, i) => (
                    <button
                      key={`${block}-${i}`}
                      onClick={() => addBlock(block)}
                      className="bg-white border-2 border-slate-100 hover:border-brand px-6 py-4 rounded-2xl font-mono text-sm font-bold text-slate-700 transition-all shadow-sm active:scale-95"
                    >
                      {block}
                    </button>
                  ))}
               </div>
            </div>

            {/* Action Check */}
            <div className="flex justify-center pt-4">
               <button 
                 onClick={checkAnswer}
                 disabled={selectedBlocks.length === 0 || isCorrect !== null}
                 className={cn(
                   "w-full sm:w-64 py-5 rounded-2xl font-black text-sm uppercase tracking-widest shadow-xl transition-all",
                   selectedBlocks.length > 0 && isCorrect === null
                    ? "bg-brand text-white hover:bg-brand-dark hover:scale-[1.02] active:scale-95 border border-accent-yellow"
                    : "bg-slate-100 text-slate-300 cursor-not-allowed"
                 )}
               >
                 Cek Rakitan!
               </button>
            </div>
          </div>
        )}

        <AnimatePresence>
          {isCorrect !== null && (
            <motion.div 
              initial={{ opacity: 0 }} 
              animate={{ opacity: 1 }} 
              exit={{ opacity: 0 }}
              className="absolute inset-0 z-50 flex items-center justify-center bg-white/40 backdrop-blur-sm pointer-events-none"
            >
              <motion.div 
                initial={{ scale: 0.5 }} 
                animate={{ scale: 1 }}
                className={cn(
                  "p-10 rounded-[3rem] shadow-2xl flex flex-col items-center gap-3 text-white",
                  isCorrect ? "bg-emerald-500" : "bg-red-500"
                )}
              >
                {isCorrect ? <CheckCircle2 size={64} /> : <XCircle size={64} />}
                <span className="text-3xl font-black uppercase italic tracking-tight">{isCorrect ? 'Sempurna!' : 'Coba Lagi'}</span>
                <p className="font-medium opacity-80">{isCorrect ? '+20 Poin ditambahkan' : 'Urutannya belum pas nih'}</p>
              </motion.div>
            </motion.div>
          )}
        </AnimatePresence>
      </div>
    </div>
  );
};

export default TagBuilder;
